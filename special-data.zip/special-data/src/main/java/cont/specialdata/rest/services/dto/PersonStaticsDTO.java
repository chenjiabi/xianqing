package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/25 11:49
 */
@Data
public class PersonStaticsDTO {
    private String person_type;

    private long allCount;

    private long queRenCount;

}
