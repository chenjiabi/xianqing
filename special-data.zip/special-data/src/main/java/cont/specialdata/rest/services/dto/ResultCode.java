package cont.specialdata.rest.services.dto;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/21 16:02
 */
public enum ResultCode implements IErrorCode {
    SUCCESS("200", "操作成功"),
    FAILED("500", "操作失败"),
    VALIDATE_FAILED("501", "参数检验失败"),
    UNAUTHORIZED("401", "认证失败"),
    FORBIDDEN("403", "没有相关权限"),
    NOTFOUND("404", "未找到相关资源");

    private String code;
    private String message;

    private ResultCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
