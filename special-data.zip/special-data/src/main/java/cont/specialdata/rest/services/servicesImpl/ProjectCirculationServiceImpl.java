package cont.specialdata.rest.services.servicesImpl;

import cont.specialdata.rest.dao.mapper.ProjectCirculationMapper;
import cont.specialdata.rest.dao.po.*;
import cont.specialdata.rest.services.UserException;
import cont.specialdata.rest.services.dto.CommonPage;
import cont.specialdata.rest.services.dto.projectDTO.*;
import cont.specialdata.rest.services.services.ProjectCirculationService;
import cont.specialdata.rest.util.ExcelExportUtil;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 13:05
 */
@Service
public class ProjectCirculationServiceImpl implements ProjectCirculationService {

    @Autowired
    ProjectCirculationMapper projectCirculationMapper;


    /**
     * 添加用户
     *
     * @param userDTO 用户信息
     */
    @Override
    @Transactional
    public String addUser(UserDTO userDTO) {
        UserPo userPo = new UserPo();
        String id = UUID.randomUUID().toString();
        userPo.setId(id);
        userPo.setAddress(userDTO.getAddress());
        userPo.setArea(userDTO.getArea());
        userPo.setContactUser(userDTO.getContactUser());
        userPo.setName(userDTO.getName());
        userPo.setOperatingPerson(userDTO.getOperatingPerson());
        userPo.setPhoneNumber(userDTO.getPhoneNumber());
        userPo.setPostCode(userDTO.getPostCode());
        userPo.setRemark(userDTO.getRemark());
        userPo.setDirector(userDTO.getDirector());
        userPo.setCreateTime(new Date());
        List<UserPo> userPos = projectCirculationMapper.selectUserByName(userDTO.getName());
        if (userPos.size() > 0) {
            throw new UserException("此单位已存在，请确认是否重复!");
        }
        projectCirculationMapper.addUser(userPo);
        return id;
    }

    /**
     * 编辑用户
     *
     * @param userDTO 用户信息
     */
    @Override
    @Transactional
    public String editUser(UserDTO userDTO) {
        UserPo userPoSource=projectCirculationMapper.selectUserById(userDTO.getId());

        UserPo userPo = new UserPo();
        userPo.setId(userDTO.getId());
        userPo.setAddress(userDTO.getAddress());
        userPo.setArea(userDTO.getArea());
        userPo.setContactUser(userDTO.getContactUser());
        userPo.setName(userDTO.getName());
        userPo.setOperatingPerson(userDTO.getOperatingPerson());
        userPo.setPhoneNumber(userDTO.getPhoneNumber());
        userPo.setPostCode(userDTO.getPostCode());
        userPo.setRemark(userDTO.getRemark());
        userPo.setDirector(userDTO.getDirector());
//        List<UserPo> userPos = projectCirculationMapper.selectUserByName(userDTO.getName());
//        if (userPos.size() > 0) {
//            throw new UserException("此单位已存在，请确认是否重复!");
//        }

        projectCirculationMapper.editUser(userPo);
        projectCirculationMapper.updateProjectUserName(userPoSource.getName(),userDTO.getName());
        projectCirculationMapper.updateReportUserName(userPoSource.getName(),userDTO.getName());
        return userDTO.getId();
    }

    /**
     * 删除用户
     *
     * @param userId 用户id
     */
    @Override
    @Transactional
    public String deleteUser(String userId) {
        projectCirculationMapper.deleteUser(userId);
        return "";
    }


    /**
     * 添加项目
     *
     * @param projectDTO 项目信息
     */
    @Override
    @Transactional
    public String addProject(ProjectDTO projectDTO) {
        ProjectPo projectPo = new ProjectPo();
        String id = UUID.randomUUID().toString();
        projectPo.setId(id);
        projectPo.setLeader(projectDTO.getLeader());
        projectPo.setOwner(projectDTO.getOwner());
        projectPo.setProjectName(projectDTO.getProjectName());
        projectPo.setRate(projectDTO.getRate());
        projectPo.setRemark(projectDTO.getRemark());
        projectPo.setCreateTime(new Date());
        List<ProjectPo> userPos = projectCirculationMapper.selectProjectByName(projectDTO.getProjectName());

        if (userPos.size() > 0) {
            throw new UserException("此项目已存在，请勿重复添加!");
        }

        projectCirculationMapper.addProject(projectPo);
        return id;
    }

    /**
     * 添加报告
     *
     * @param reportDTO 报告信息
     */
    @Override
    @Transactional
    public String addReport(AddReportDTO reportDTO) {
        AddReportPo addReportPo = new AddReportPo();
        String id = UUID.randomUUID().toString();
        addReportPo.setId(id);
        addReportPo.setAuditPerson(reportDTO.getAuditPerson());
        addReportPo.setEntrustedUnit(reportDTO.getEntrustedUnit());
        addReportPo.setIssuer(reportDTO.getIssuer());
        addReportPo.setIsUpload(reportDTO.getIsUpload());
        addReportPo.setLastTime(reportDTO.getLastTime());
        addReportPo.setOutboundNo(reportDTO.getOutboundNo());
        addReportPo.setOverProof(reportDTO.getOverProof());
        addReportPo.setPreparedPerson(reportDTO.getPreparedPerson());
        addReportPo.setProjectName(reportDTO.getProjectName());
        addReportPo.setProvinceNo(reportDTO.getProvinceNo());
        addReportPo.setRecieveTime(reportDTO.getRecieveTime());
        addReportPo.setRecipient(reportDTO.getRecipient());
        addReportPo.setRemark(reportDTO.getRemark());
        addReportPo.setSampleNo(reportDTO.getSampleNo());
        addReportPo.setType(reportDTO.getType());
        addReportPo.setReportName(reportDTO.getReportName());
        addReportPo.setState(0);
        addReportPo.setBigNo(0);
        addReportPo.setCreateTime(new Date());
        //当编制填写了时
        if(reportDTO.getPreparedPerson()!=null&&!reportDTO.getPreparedPerson().equals(""))
        {
            addReportPo.setState(1);
        }


        String bigNo=reportDTO.getOutboundNo().replace(reportDTO.getType(),"");
        try {
            addReportPo.setBigNo(Integer.parseInt(bigNo));
        }catch (Exception e)
        {
            throw new UserException("出站号与类型不符，请检查后重新输入");
        }
        if(reportDTO.getSmallNo()!=null&&reportDTO.getSmallNo().size()>0)
        {
            String smallNos="";
            for(int i=0;i<reportDTO.getSmallNo().size();i++)
            {
                if(i!=(reportDTO.getSmallNo().size()-1))
                {
                    smallNos+=reportDTO.getSmallNo().get(i)+",";
                }
                else
                {
                    smallNos+=reportDTO.getSmallNo().get(i);
                }
            }
            addReportPo.setSmallNo(smallNos);
        }


        Calendar currentCar=Calendar.getInstance();
        int currentYear=currentCar.get(Calendar.YEAR);
        Calendar beginCar=Calendar.getInstance();
        beginCar.set(Calendar.YEAR,currentYear);
        beginCar.set(Calendar.MONTH,0);
        beginCar.set(Calendar.DAY_OF_MONTH,1);
        beginCar.set(Calendar.HOUR_OF_DAY,0);
        beginCar.set(Calendar.MINUTE,0);
        beginCar.set(Calendar.SECOND,0);
        Date beginDate=beginCar.getTime();
        List<ReportPo> oldReports=projectCirculationMapper.getReportByOutboundNo(addReportPo.getOutboundNo(),beginDate,new Date());
        if(oldReports.size()>0)
        {
            throw new UserException("出站号已存在，请重新输入");
        }
        projectCirculationMapper.addReport(addReportPo);
        return id;
    }
    /**
     * 编辑报告
     *
     * @param editReportDTO 报告信息
     */
    @Override
    @Transactional
    public String editReport(EditReportDTO editReportDTO) {
        ReportPo sourceReportPo=projectCirculationMapper.getReportById(editReportDTO.getId());
        EditReportPo editReportPo = new EditReportPo();
        editReportPo.setId(editReportDTO.getId());
        editReportPo.setAuditPerson(editReportDTO.getAuditPerson());
        editReportPo.setEntrustedUnit(editReportDTO.getEntrustedUnit());
        editReportPo.setIssuer(editReportDTO.getIssuer());
        editReportPo.setIsUpload(editReportDTO.getIsUpload());
        editReportPo.setLastTime(editReportDTO.getLastTime());
        editReportPo.setOutboundNo(editReportDTO.getOutboundNo());
        editReportPo.setOverProof(editReportDTO.getOverProof());
        editReportPo.setPreparedPerson(editReportDTO.getPreparedPerson());
        editReportPo.setProjectName(editReportDTO.getProjectName());
        editReportPo.setProvinceNo(editReportDTO.getProvinceNo());
        editReportPo.setRecieveTime(editReportDTO.getRecieveTime());
        editReportPo.setRecipient(editReportDTO.getRecipient());
        editReportPo.setRemark(editReportDTO.getRemark());
        editReportPo.setSampleNo(editReportDTO.getSampleNo());
        editReportPo.setRealAuditPerson(editReportDTO.getRealAuditPerson());
        editReportPo.setRealIssuer(editReportDTO.getRealIssuer());
        editReportPo.setRealPreparedPerson(editReportDTO.getRealPreparedPerson());
        editReportPo.setType(editReportDTO.getType());
        editReportPo.setState(sourceReportPo.getState());
        editReportPo.setAuditTime(editReportDTO.getAuditTime());
        editReportPo.setHandoverTime(editReportDTO.getHandoverTime());
        editReportPo.setReportTime(editReportDTO.getReportTime());
        editReportPo.setBigNo(0);
        editReportPo.setReportName(editReportDTO.getReportName());
        editReportPo.setRecieveTime(editReportDTO.getRecipientTime());
        String bigNo=editReportDTO.getOutboundNo().replace(editReportDTO.getType(),"");

        try {
            editReportPo.setBigNo(Integer.parseInt(bigNo));
        }catch (Exception e)
        {
            throw new UserException("出站号与类型不符，请检查后重新输入");
        }


        if(editReportDTO.getSmallNo()!=null&&editReportDTO.getSmallNo().size()>0)
        {
            String smallNos="";
            for(int i=0;i<editReportDTO.getSmallNo().size();i++)
            {
                if(i!=(editReportDTO.getSmallNo().size()-1))
                {
                    smallNos+=editReportDTO.getSmallNo().get(i)+",";
                }
                else
                {
                    smallNos+=editReportDTO.getSmallNo().get(i);
                }
            }
            editReportPo.setSmallNo(smallNos);
        }

              //当编制填写了时
        if(editReportDTO.getPreparedPerson()!=null&&!editReportDTO.getPreparedPerson().equals(""))
        {
            editReportPo.setState(1);
        }
        //当审核人员填写了时
        if(editReportDTO.getAuditPerson()!=null&&!editReportDTO.getAuditPerson().equals(""))
        {
            editReportPo.setState(2);
        }
        //当签发人员填写了时
        if(editReportDTO.getIssuer()!=null&&!editReportDTO.getIssuer().equals(""))
        {
            editReportPo.setState(3);
        }

        //当审核签发交接时间都不为空
        if(editReportDTO.getReportTime()!=null&&editReportDTO.getHandoverTime()!=null&&
                editReportDTO.getPreparedPerson()!=null&&!editReportDTO.getPreparedPerson().equals("")
        &&editReportDTO.getAuditPerson()!=null&&!editReportDTO.getAuditPerson().equals("")
        &&editReportDTO.getIssuer()!=null&&!editReportDTO.getIssuer().equals(""))
        {
            editReportPo.setState(4);
        }
        //当领取人填写了时
        if(editReportDTO.getRecipient()!=null&&!editReportDTO.getRecipient().equals("")&&editReportDTO.getRecipientTime()!=null)
        {
            editReportPo.setState(5);
        }
        if((sourceReportPo.getSampleNo()==null&&editReportDTO.getSampleNo()!=null)||!sourceReportPo.getSampleNo().equals(editReportDTO.getSampleNo()))
        {
            editReportPo.setState(1);
            editReportPo.setAuditPerson(null);
            editReportPo.setIssuer(null);
        }
        Calendar currentCar=Calendar.getInstance();
        int currentYear=currentCar.get(Calendar.YEAR);
        Calendar beginCar=Calendar.getInstance();
        beginCar.set(Calendar.YEAR,currentYear);
        beginCar.set(Calendar.MONTH,0);
        beginCar.set(Calendar.DAY_OF_MONTH,1);
        beginCar.set(Calendar.HOUR_OF_DAY,0);
        beginCar.set(Calendar.MINUTE,0);
        beginCar.set(Calendar.SECOND,0);
        Date beginDate=beginCar.getTime();
        List<ReportPo> oldReports=projectCirculationMapper.getReportByOutboundNo(editReportPo.getOutboundNo(),beginDate,new Date());
        if(oldReports.size()>1)
        {
            throw new UserException("出站号已存在，请重新输入");
        }
        projectCirculationMapper.editReport(editReportPo);
        return editReportDTO.getId();
    }

    /**
     * 删除报告
     *
     */
    public void deleteReport(String reportId)
    {
        projectCirculationMapper.deleteReport(reportId);
    }
    /**
     * 上报报告
     *
     */
    public void report(String reportId)
    {
        projectCirculationMapper.report(reportId,new Date());
    }
    /**
     * 交接报告
     *
     */
    public void handover(String reportId)
    {
        projectCirculationMapper.handover(reportId,new Date());
    }



    /**
     * 编辑项目
     *
     * @param projectDTO 项目信息
     */
    @Override
    @Transactional
    public String editProject(ProjectDTO projectDTO) {
        ProjectPo sourcePo=projectCirculationMapper.selectProjectById(projectDTO.getId());

        ProjectPo projectPo = new ProjectPo();
        projectPo.setId(projectDTO.getId());
        projectPo.setLeader(projectDTO.getLeader());
        projectPo.setOwner(projectDTO.getOwner());
        projectPo.setProjectName(projectDTO.getProjectName());
        projectPo.setRate(projectDTO.getRate());
        projectPo.setRemark(projectDTO.getRemark());
//        List<ProjectPo> userPos = projectCirculationMapper.selectProjectByName(projectDTO.getProjectName());
//        if (userPos.size() > 0) {
//            throw new UserException("此项目已存在，请勿重复添加!");
//        }
        projectCirculationMapper.editProject(projectPo);
        projectCirculationMapper.updateReportProjectName(sourcePo.getProjectName(),projectDTO.getProjectName());
        return projectDTO.getId();
    }

    /**
     * 删除项目
     *
     * @param projectId 项目id
     */
    @Override
    @Transactional
    public String deleteProject(String projectId) {
        projectCirculationMapper.deleteProject(projectId);
        return "";
    }

    /**
     * 根据条件查询用户信息
     */
    public CommonPage<UserDTO> getUserPage(String name, String phoneNumber, int pageIndex, int pageSize) {
        if (name != null && !name.equals("")) {
            name = "%" + name + "%";
        }
        if (phoneNumber != null && !phoneNumber.equals("")) {
            phoneNumber = "%" + phoneNumber + "%";
        }

        List<UserPo> userPoList = projectCirculationMapper.getUserPage(name, phoneNumber, pageIndex, pageSize);

        long count = projectCirculationMapper.getUserCount(name, phoneNumber);

        CommonPage Page = new CommonPage(pageIndex, pageSize, count, userPoList);
        return Page;

    }

    /**
     * 根据条件查询项目信息
     */
    public CommonPage<ProjectDetialDTO> getProjectPage(String projectName, String userName, int pageIndex, int pageSize) {
        if (projectName != null && !projectName.equals("")) {
            projectName = "%" + projectName + "%";
        }
        if (userName != null && !userName.equals("")) {
            userName = "%" + userName + "%";
        }
        List<ProjectDetialPo> projectDetialPos = projectCirculationMapper.getProjectPage(projectName, userName, pageIndex, pageSize);
        long count = projectCirculationMapper.getProjectCount(projectName, userName);
        List<ProjectDetialDTO> projectDetialDTOS=new ArrayList<>();
        for(int i=0;i<projectDetialPos.size();i++)
        {
            ProjectDetialDTO projectDetial=new ProjectDetialDTO();
            if(projectDetialPos.get(i).getRate()==1) {
                projectDetial.setAllProgress(12);
            }else  if(projectDetialPos.get(i).getRate()==2) {
                projectDetial.setAllProgress(4);
            }else  if(projectDetialPos.get(i).getRate()==3) {
                projectDetial.setAllProgress(2);
            }

            projectDetial.setRate(projectDetialPos.get(i).getRate());
            projectDetial.setId(projectDetialPos.get(i).getId());
            projectDetial.setLeader(projectDetialPos.get(i).getLeader());
            projectDetial.setOwner(projectDetialPos.get(i).getOwner());
            projectDetial.setProjectName(projectDetialPos.get(i).getProjectName());
            projectDetial.setRemark(projectDetialPos.get(i).getRemark());
            projectDetial.setCurrentProgress(projectDetialPos.get(i).getCurrentProgress());
            projectDetialDTOS.add(projectDetial);

        }

        CommonPage Page = new CommonPage(pageIndex, pageSize, count, projectDetialDTOS);
        return Page;
    }

    /**
     * 根据条件查询报告信息
     */
    public CommonPage<ReportDTO> getReportPage(String type, int state,String userName,String sampleNo, String reportName,int pageIndex, int pageSize) {
        if (userName != null && !userName.equals("")) {
            userName = "%" + userName + "%";
        }
        if (sampleNo != null && !sampleNo.equals("")) {
            sampleNo = "%" + sampleNo + "%";
        }
        if (reportName != null && !reportName.equals("")) {
            reportName = "%" + reportName + "%";
        }
        List<ReportPo> reportPoList = projectCirculationMapper.getReportPage(type,state, userName, sampleNo,reportName,pageIndex, pageSize);
        long count = projectCirculationMapper.getReportCount(type,state, userName,sampleNo,reportName);
        List<ReportDTO> reportDTOList=new ArrayList<>();
        for(int i=0;i<reportPoList.size();i++)
        {
            ReportDTO reportDTO=new ReportDTO();
            reportDTO.setAuditPerson(reportPoList.get(i).getAuditPerson());
            reportDTO.setEntrustedUnit(reportPoList.get(i).getEntrustedUnit());
            reportDTO.setHandoverTime(reportPoList.get(i).getHandoverTime());
            reportDTO.setId(reportPoList.get(i).getId());
            reportDTO.setIssuer(reportPoList.get(i).getIssuer());
            reportDTO.setIsUpload(reportPoList.get(i).getIsUpload());
            reportDTO.setLastTime(reportPoList.get(i).getLastTime());
            reportDTO.setOutboundNo(reportPoList.get(i).getOutboundNo());
            reportDTO.setOverProof(reportPoList.get(i).getOverProof());
            reportDTO.setPreparedPerson(reportPoList.get(i).getPreparedPerson());
            reportDTO.setProjectName(reportPoList.get(i).getProjectName());
            reportDTO.setProvinceNo(reportPoList.get(i).getProvinceNo());
            reportDTO.setRealAuditPerson(reportPoList.get(i).getRealAuditPerson());
            reportDTO.setRealIssuer(reportPoList.get(i).getRealIssuer());
            reportDTO.setRecieveTime(reportPoList.get(i).getRecieveTime());
            reportDTO.setRecipient(reportPoList.get(i).getRecipient());
            reportDTO.setRemark(reportPoList.get(i).getRemark());
            reportDTO.setReportTime(reportPoList.get(i).getReportTime());
            reportDTO.setSampleNo(reportPoList.get(i).getSampleNo());
            reportDTO.setState(reportPoList.get(i).getState());
            reportDTO.setType(reportPoList.get(i).getType());
            reportDTO.setReportName(reportPoList.get(i).getReportName());
            reportDTO.setRecipientTime(reportPoList.get(i).getRecipientTime());
            if(reportPoList.get(i).getSmallNo()!=null&&!reportPoList.get(i).getSmallNo().equals("")) {
                String[] smallNos =reportPoList.get(i).getSmallNo().split(",");
                List<String> smallNoStrings=new ArrayList<>();
                for(int j=0;j<smallNos.length;j++)
                {
                    smallNoStrings.add(smallNos[j]);
                }
                reportDTO.setSmallNo(smallNoStrings);
            }
            reportDTOList.add(reportDTO);
        }

        CommonPage Page = new CommonPage(pageIndex, pageSize, count, reportDTOList);
        return Page;
    }
    /**
     * 根据项目Id查询报告信息
     */
    public List<ReportDTO> getReportByProjectId(String projectId)
    {
        List<ReportDTO> reportDTOS=new ArrayList<>();
        List<ReportPo>  reportPoList=projectCirculationMapper.getReportByProjectId(projectId);
        for(int i=0;i<reportPoList.size();i++)
        {
            ReportDTO reportDTO=new ReportDTO();
            reportDTO.setAuditPerson(reportPoList.get(i).getAuditPerson());
            reportDTO.setEntrustedUnit(reportPoList.get(i).getEntrustedUnit());
            reportDTO.setHandoverTime(reportPoList.get(i).getHandoverTime());
            reportDTO.setId(reportPoList.get(i).getId());
            reportDTO.setIssuer(reportPoList.get(i).getIssuer());
            reportDTO.setIsUpload(reportPoList.get(i).getIsUpload());
            reportDTO.setLastTime(reportPoList.get(i).getLastTime());
            reportDTO.setOutboundNo(reportPoList.get(i).getOutboundNo());
            reportDTO.setOverProof(reportPoList.get(i).getOverProof());
            reportDTO.setPreparedPerson(reportPoList.get(i).getPreparedPerson());
            reportDTO.setProjectName(reportPoList.get(i).getProjectName());
            reportDTO.setProvinceNo(reportPoList.get(i).getProvinceNo());
            reportDTO.setRealAuditPerson(reportPoList.get(i).getRealAuditPerson());
            reportDTO.setRealIssuer(reportPoList.get(i).getRealIssuer());
            reportDTO.setRecieveTime(reportPoList.get(i).getRecieveTime());
            reportDTO.setRecipient(reportPoList.get(i).getRecipient());
            reportDTO.setRemark(reportPoList.get(i).getRemark());
            reportDTO.setReportTime(reportPoList.get(i).getReportTime());
            reportDTO.setSampleNo(reportPoList.get(i).getSampleNo());
            reportDTO.setState(reportPoList.get(i).getState());
            reportDTO.setType(reportPoList.get(i).getType());
            reportDTO.setReportName(reportPoList.get(i).getReportName());
            reportDTO.setRecipientTime(reportPoList.get(i).getRecipientTime());
            if(reportPoList.get(i).getSmallNo()!=null&&!reportPoList.get(i).getSmallNo().equals("")) {
                String[] smallNos =reportPoList.get(i).getSmallNo().split(",");
                List<String> smallNoStrings=new ArrayList<>();
                for(int j=0;j<smallNos.length;j++)
                {
                    smallNoStrings.add(smallNos[j]);
                }
                reportDTO.setSmallNo(smallNoStrings);
            }
            reportDTOS.add(reportDTO);
        }
        return reportDTOS;
    }

    /**
     * 根据Id查询报告详细信息
     */
    public  ReportDTO getReportById(String id)
    {
        ReportDTO reportDTO=new ReportDTO();
        ReportPo reportPo=projectCirculationMapper.getReportById(id);
        if(reportPo!=null)
        {
            reportDTO.setAuditPerson(reportPo.getAuditPerson());
            reportDTO.setEntrustedUnit(reportPo.getEntrustedUnit());
            reportDTO.setHandoverTime(reportPo.getHandoverTime());
            reportDTO.setId(reportPo.getId());
            reportDTO.setIssuer(reportPo.getIssuer());
            reportDTO.setIsUpload(reportPo.getIsUpload());
            reportDTO.setLastTime(reportPo.getLastTime());
            reportDTO.setOutboundNo(reportPo.getOutboundNo());
            reportDTO.setOverProof(reportPo.getOverProof());
            reportDTO.setPreparedPerson(reportPo.getPreparedPerson());
            reportDTO.setProjectName(reportPo.getProjectName());
            reportDTO.setProvinceNo(reportPo.getProvinceNo());
            reportDTO.setRealAuditPerson(reportPo.getRealAuditPerson());
            reportDTO.setRealIssuer(reportPo.getRealIssuer());
            reportDTO.setRecieveTime(reportPo.getRecieveTime());
            reportDTO.setRecipient(reportPo.getRecipient());
            reportDTO.setRemark(reportPo.getRemark());
            reportDTO.setReportTime(reportPo.getReportTime());
            reportDTO.setSampleNo(reportPo.getSampleNo());
            reportDTO.setState(reportPo.getState());
            reportDTO.setType(reportPo.getType());
            reportDTO.setReportName(reportPo.getReportName());
            reportDTO.setRecipientTime(reportPo.getRecipientTime());
            if(reportPo.getSmallNo()!=null&&!reportPo.getSmallNo().equals("")) {
                String[] smallNos =reportPo.getSmallNo().split(",");
                List<String> smallNoStrings=new ArrayList<>();
                for(int j=0;j<smallNos.length;j++)
                {
                    smallNoStrings.add(smallNos[j]);
                }
                reportDTO.setSmallNo(smallNoStrings);
            }
        }
        return reportDTO;
    }



    /**
     * 根据数据类型获取代码表
     */
    public List<CodeItem> getCodeItem(String type) {
        List<CodeItem> codeItems = new ArrayList<>();

        List<CodeItemPo> codeItemPos = projectCirculationMapper.getCodeItem(type);
        for (int i = 0; i < codeItemPos.size(); i++) {
            CodeItem codeItem = new CodeItem();
            codeItem.setCode(codeItemPos.get(i).getCode());
            codeItem.setId(codeItemPos.get(i).getId());
            codeItem.setName(codeItemPos.get(i).getName());
            codeItem.setOrderNo(codeItemPos.get(i).getOrderNo());
            codeItem.setType(codeItemPos.get(i).getType());
            codeItems.add(codeItem);
        }
        return codeItems;
    }


    private String getTypeName(String type) {
        List<CodeItemPo> codeItemPos = projectCirculationMapper.getCodeItem("category");
        for (int i = 0; i < codeItemPos.size(); i++) {
            if (codeItemPos.get(i).getCode().equals(type)) {
                return codeItemPos.get(i).getName();
            }
        }
        return "";
    }
    /**
     * 获取单位名称
     */
    public List<String> getUnitName(String name)
    {
        if(name!=null&&!name.equals(""))
        {
            name="%"+name+"%";
        }
return projectCirculationMapper.getUnitName(name);
    }


    /**
     * 获取项目名称
     */
    public List<String> getProjectName(String name,String entrustedUnit) {
        if (name != null && !name.equals("")) {
            name = "%" + name + "%";
        }
        if (entrustedUnit != null && !entrustedUnit.equals("")) {
            entrustedUnit = "%" + entrustedUnit + "%";
        }
        return projectCirculationMapper.getProjectName(name,entrustedUnit);
    }



    /**
     * 统计一周的报告
     */
    public List<WeekReportDTO> statisticsWeek(Date beginDate)
    {
        Calendar currentCalendar1 = Calendar.getInstance(TimeZone.getTimeZone("GMT+8"));
        currentCalendar1.setTime(beginDate);
        currentCalendar1.add(Calendar.DAY_OF_MONTH,-3);

        Calendar currentCalendar2 = Calendar.getInstance(TimeZone.getTimeZone("GMT+8"));
        currentCalendar2.setTime(beginDate);
        currentCalendar2.add(Calendar.DAY_OF_MONTH,3);

        List<ReportPo>  reportPoList=projectCirculationMapper.statisticsWeek(currentCalendar1.getTime(),currentCalendar2.getTime());

        List<WeekReportDTO> weekReportDTOS=new ArrayList<>();
        for(int i=0;i<reportPoList.size();i++)
        {
            if (weekReportDTOS.stream().map(WeekReportDTO::getLastTime).collect(Collectors.toList()).contains(reportPoList.get(i).getLastTime())) {
                for(int j=0;j<weekReportDTOS.size();j++)
                {
                    if(weekReportDTOS.get(j).getLastTime().equals(reportPoList.get(i).getLastTime()))
                    {
                        BriefReportDTO briefReportDTO=new BriefReportDTO();
                        briefReportDTO.setId(reportPoList.get(i).getId());
                        briefReportDTO.setRealAuditPerson(reportPoList.get(i).getAuditPerson());
                        briefReportDTO.setPreparedPerson(reportPoList.get(i).getPreparedPerson());
                        briefReportDTO.setRealIssuer(reportPoList.get(i).getIssuer());
                        briefReportDTO.setProjectName(reportPoList.get(i).getProjectName());
                        briefReportDTO.setState(reportPoList.get(i).getState());
                        briefReportDTO.setOutboundNo(reportPoList.get(i).getOutboundNo());
                        weekReportDTOS.get(j).getBriefReportDTOS().add(briefReportDTO);
                    }
                }

            }
            else
            {
                WeekReportDTO weekReportDTO=new WeekReportDTO();
                weekReportDTO.setLastTime(reportPoList.get(i).getLastTime());
                List<BriefReportDTO> briefReportDTOS=new ArrayList<>();
                weekReportDTO.setBriefReportDTOS(briefReportDTOS);
                BriefReportDTO briefReportDTO=new BriefReportDTO();
                briefReportDTO.setId(reportPoList.get(i).getId());
                briefReportDTO.setProjectName(reportPoList.get(i).getProjectName());
                briefReportDTO.setState(reportPoList.get(i).getState());
                briefReportDTO.setRealAuditPerson(reportPoList.get(i).getRealAuditPerson());
                briefReportDTO.setPreparedPerson(reportPoList.get(i).getPreparedPerson());
                briefReportDTO.setRealIssuer(reportPoList.get(i).getRealIssuer());
                briefReportDTO.setOutboundNo(reportPoList.get(i).getOutboundNo());
                weekReportDTO.getBriefReportDTOS().add(briefReportDTO);
                weekReportDTOS.add(weekReportDTO);
            }

        }

        for(int i=0;i<7;i++)
        {
            Calendar currentCalendar3= currentCalendar1;
            if(!weekReportDTOS.stream().map(WeekReportDTO::getLastTime).collect(Collectors.toList()).contains(currentCalendar3.getTime()))
            {
                WeekReportDTO weekReportDTO=new WeekReportDTO();
                weekReportDTO.setLastTime(currentCalendar3.getTime());
                List<BriefReportDTO> briefReportDTOS=new ArrayList<>();
                weekReportDTO.setBriefReportDTOS(briefReportDTOS);
                weekReportDTOS.add(weekReportDTO);
            }
            currentCalendar3.add(Calendar.DAY_OF_MONTH,1);
        }


         return weekReportDTOS;
    }

    /**
     * 根据类型获取出站号
     */
    public String getOutboundNoByType(String type)
    {
        String outBoundNo=type;
        try {
            if(type.equals("SK")||type.equals("SQ")||type.equals("S"))
            {
                Calendar currentCar=Calendar.getInstance();
                int currentMonth=currentCar.get(Calendar.MONTH);
                Calendar beginCar=Calendar.getInstance();
                beginCar.set(Calendar.MONTH,currentMonth);
                beginCar.set(Calendar.DAY_OF_MONTH,1);
                beginCar.set(Calendar.HOUR_OF_DAY,0);
                beginCar.set(Calendar.MINUTE,0);
                beginCar.set(Calendar.SECOND,0);
                Date beginDate=beginCar.getTime();

                long bigNo = projectCirculationMapper.getOutboundNoByType(type,beginDate,new Date());

                int currentYear=currentCar.get(Calendar.YEAR);
                int month=currentCar.get(Calendar.MONTH)+1;
                String yearString=(currentYear+"").substring(2,4);
                String monthString ="";
                if(month<10)
                {
                    monthString="0"+month;
                }
                else
                {
                    monthString=""+month;
                }
                if ((bigNo + 1) < 10) {
                    outBoundNo = type+yearString+monthString + "00" + (bigNo + 1);
                } else if ((bigNo + 1) < 100) {
                    outBoundNo = type+yearString+monthString + "0" + (bigNo + 1);
                }
                else  {
                    outBoundNo = type+yearString+monthString + "" + (bigNo + 1);
                }
                return outBoundNo;
            }else
            {
               Calendar currentCar=Calendar.getInstance();
                int currentYear=currentCar.get(Calendar.YEAR);
                Calendar beginCar=Calendar.getInstance();
                beginCar.set(Calendar.YEAR,currentYear);
                beginCar.set(Calendar.MONTH,0);
                beginCar.set(Calendar.DAY_OF_MONTH,1);
                beginCar.set(Calendar.HOUR_OF_DAY,0);
                beginCar.set(Calendar.MINUTE,0);
                beginCar.set(Calendar.SECOND,0);
                Date beginDate=beginCar.getTime();

                long bigNo = projectCirculationMapper.getOutboundNoByType(type,beginDate,new Date());
                if ((bigNo + 1) < 10) {
                    outBoundNo = type + "000" + (bigNo + 1);
                } else if ((bigNo + 1) < 100) {
                    outBoundNo = type + "00" + (bigNo + 1);
                }else if ((bigNo + 1) < 1000) {
                    outBoundNo = type + "0" + (bigNo + 1);
                }
                else  {
                    outBoundNo = type + "" + (bigNo + 1);
                }
                return outBoundNo;
            }

        }catch (Exception e)
        {
            if(type.equals("SK")||type.equals("SQ")||type.equals("S")) {
                Calendar currentCar=Calendar.getInstance();
                int currentYear=currentCar.get(Calendar.YEAR);
                int month=currentCar.get(Calendar.MONTH)+1;
                String yearString=(currentYear+"").substring(2,4);
                String monthString ="";
                if(month<10)
                {
                    monthString="0"+month;
                }
                else
                {
                    monthString=""+month;
                }
                return type+yearString+monthString+"001";

            }else {
                return type + "0001";
            }
        }
    }

    /**
     * 领取
     */
    public void recipient(String reportId,String recipient)
    {
        projectCirculationMapper.recipient(reportId,recipient,new Date());
    }

    /**
     * 导出报告
     */
    public ByteArrayOutputStream exportReport(String type, int state,String userName,String sampleNo, String reportName) throws IOException {
        //写入Excel
        ExcelExportUtil excelExport2 = new ExcelExportUtil();
        List<ReportPo> reportPoList = projectCirculationMapper.getReportPage(type,state, userName, sampleNo,reportName,1, 2000);
        //写入表名
        excelExport2.setSheetName("报告列表");

        //写入表头
        String[] tableHead = new String[]{"序号","类型", "出站号", "小编号", "省厅编号","是否上传","委托单位","报告名称",
                "样品编号", "收录时间", "报告时间","报告是否超标", "编制人","审核人", "审核时间","签发人", "签发时间","报告交接时间", "领取人",
                "领取时间", "备注"};
        excelExport2.setHeadList(tableHead);
        //写入标题
        DateFormat formatBegin2 = new SimpleDateFormat("yyyy-MM-dd");
        formatBegin2.setTimeZone(TimeZone.getTimeZone("GMT+0"));
        String title =  "报告列表";
        excelExport2.setTitle(title);

        //数据赋值
        List<List<Object>> data = new ArrayList<>();
        for (int i = 0; i < reportPoList.size(); i++) {
            ReportPo temp = reportPoList.get(i);
                List<Object> item = new ArrayList<>();
                item.add(i + 1);
                item.add(getTypeName(temp.getType()));
            item.add(temp.getOutboundNo());
                item.add(temp.getSmallNo());
            item.add(temp.getProvinceNo());
            String isUpload="否";
            String overProof="否";
            if(temp.getIsUpload()==1)
            {
                isUpload="是";
            }
            if(temp.getOverProof()==1)
            {
                overProof="是";
            }
            item.add(isUpload);
            item.add(temp.getEntrustedUnit());
            item.add(temp.getReportName());
            item.add(temp.getSampleNo());
            if (temp.getRecieveTime() != null) {
                String time = formatBegin2.format(temp.getRecieveTime());
                item.add(time);
            } else {
                item.add("");
            }
            if (temp.getLastTime() != null) {
                String time = formatBegin2.format(temp.getLastTime());
                item.add(time);
            } else {
                item.add("");
            }
            item.add(overProof);
            item.add(temp.getPreparedPerson());
            item.add(temp.getAuditPerson());
            if (temp.getAuditTime() != null) {
                String time = formatBegin2.format(temp.getAuditTime());
                item.add(time);
            } else {
                item.add("");
            }
            item.add(temp.getIssuer());
            if (temp.getReportTime() != null) {
                String time = formatBegin2.format(temp.getReportTime());
                item.add(time);
            } else {
                item.add("");
            }
            if (temp.getHandoverTime() != null) {
                String time = formatBegin2.format(temp.getHandoverTime());
                item.add(time);
            } else {
                item.add("");
            }
            item.add(temp.getRecipient());
            if (temp.getRecipientTime() != null) {
                String time = formatBegin2.format(temp.getRecipientTime());
                item.add(time);
            } else {
                item.add("");
            }
            item.add(temp.getRemark());
                data.add(item);

        }
        excelExport2.setRowHeight(20);
        //写入标题和表头
        excelExport2.writeTitle(35, 20);
        excelExport2.writeTableHead(excelExport2.getHeadStyle(excelExport2.getWorkbook(), 12), 1, 36);

        excelExport2.setColumnWidth(9, 256 * 36);

        ByteArrayOutputStream outputStream = ExcelExportUtil.writeToOutputStream(data, excelExport2, 2, 12);
        return outputStream;
    }

}
