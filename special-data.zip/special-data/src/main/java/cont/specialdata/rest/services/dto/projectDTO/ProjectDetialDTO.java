package cont.specialdata.rest.services.dto.projectDTO;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 17:45
 */
@Data
public class ProjectDetialDTO {
    private String id;


    private String projectName;

    private String owner;

    private String leader;

    private short rate;

    private String remark;

    private int allProgress;

    private int currentProgress;
}
