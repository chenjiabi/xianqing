package cont.specialdata.rest.services.dto.projectDTO;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/23 14:25
 */
@Data
public class BriefReportDTO {
    private String id;
    private String outboundNo;
    private String projectName;
    private String preparedPerson;
    private String realAuditPerson;
    private String realIssuer;
    private int state;
}
