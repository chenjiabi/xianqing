package cont.specialdata.rest.services.services;

import cont.specialdata.rest.services.client.FileContent;
import cont.specialdata.rest.services.dto.CommonResult;
import cont.specialdata.rest.services.dto.FileDTO;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 10:32
 */
public interface FileOperationService {
    /**
     * 输出文件
     *
     * @param response
     */
    void responseStream(FileContent fileContent, HttpServletResponse response);
    /**
     * 上传文件
     * @param multipFile
     * @return
     */
    CommonResult<FileDTO> uploadFile(MultipartFile multipFile);



    /**
     * 下载文件
     * @param fileId
     * @param fileName
     * @return
     */
    FileContent getFileById(String fileId, String fileName);


    /**
     * 下载文件的衍射产品pdf文件
     * @param fileId
     * @param fileName
     * @return
     */
    FileContent getPdfFileById(String fileId,String fileName);


    /**
     * 生成数据库中文件的 缩略图
     *
     * @param id 数据库中文件id
     * @return 转换成功后的文件id，为空时表示不支持
     */
    String buildThumbnail(String id);

    /**
     *  上传图片文件
     * @param inputStream 文件流
     * @param fileName  文件名
     * @param contentType 文件类型
     * @return
     */
    CommonResult<FileDTO> uploadFile(InputStream inputStream, String fileName, String contentType);
}