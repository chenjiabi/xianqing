package cont.specialdata.rest.services.dto.projectDTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/23 14:22
 */
@Data
public class WeekReportDTO {
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date lastTime;

    List<BriefReportDTO> briefReportDTOS;
}
