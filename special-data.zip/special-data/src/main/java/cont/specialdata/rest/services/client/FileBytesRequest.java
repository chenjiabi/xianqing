package cont.specialdata.rest.services.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 9:52
 */
@Data
public class FileBytesRequest {

    @JsonProperty(value = "original_name")
    private String originalName;

    /***
     * 文件的base64文件字符码
     * File uploadFile=new File(...)
     * String file=Base64.encodeBase64String(org.apache.commons.io.FileUtils.FileUtils.readFileToByteArray(uploadFile));
     */
    private String file;

    @JsonProperty(value = "media_type")
    private String mediaType;
}
