package cont.specialdata.rest.dao.po;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/25 11:42
 */
@Data
public class PersonStaticsPo {
    private String person_type;

    private long allCount;


    //实到
    private long shiDaoCount;
}
