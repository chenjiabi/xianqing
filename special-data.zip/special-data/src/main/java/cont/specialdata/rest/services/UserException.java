package cont.specialdata.rest.services;

import cont.specialdata.rest.services.dto.ErrorCodeException;

/**
 * 用户可见的异常
 */
public class UserException extends ErrorCodeException {

    public UserException(String message) {
        super(message);
    }

    public UserException(String message, String code) {
        super(message, code);
    }

    public UserException(String message, Throwable cause) {
        super(message, cause);
    }

    public UserException(String message, Throwable cause, String code) {
        super(message, cause, code);
    }

    public UserException(Throwable cause, String code) {
        super(cause, code);
    }

    public UserException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, String code) {
        super(message, cause, enableSuppression, writableStackTrace, code);
    }
}
