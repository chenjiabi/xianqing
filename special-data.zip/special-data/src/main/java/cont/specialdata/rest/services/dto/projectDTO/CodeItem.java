package cont.specialdata.rest.services.dto.projectDTO;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 19:58
 */
@Data
public class CodeItem {
    private String id;


    private String name;

    private String type;

    private String code;

    private int orderNo;
}
