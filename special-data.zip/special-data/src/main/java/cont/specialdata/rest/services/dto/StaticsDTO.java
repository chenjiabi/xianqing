package cont.specialdata.rest.services.dto;

import lombok.Data;

import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/21 21:38
 */
@Data
public class StaticsDTO {
    //总人数
    private long allCount;
    //已确认人数
    private long confirmedCount;
    //总选手人数
    private long xsCount;
    //已检录选手人数
    private long jlCount;
    //已确认人数统计
    private List<PersonStaticsDTO> queRenPersonStaticsDTOS;

    //检录人数统计
    private List<PersonStaticsDTO> jianLuPersonStaticsDTOS;

}
