package cont.specialdata.rest.services.dto;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/21 16:02
 */
public interface IErrorCode {
    String getCode();

    String getMessage();
}

