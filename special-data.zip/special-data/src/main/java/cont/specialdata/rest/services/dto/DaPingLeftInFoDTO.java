package cont.specialdata.rest.services.dto;

import cont.specialdata.rest.dao.po.PersonStaticsPo;
import lombok.Data;

import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 11:01
 */
@Data
public class DaPingLeftInFoDTO {
    //男女比例
    private SexRatio sexRatio;

    //选手组成
    private List<XuanShouZc> xuanShouZcList;

    //参赛人数排名
    private List<PersonStaticsDTO> personStaticsDTOS;

    //平台排名
    private List<PingTaiStaticsDTO> pingTaiStaticsDTOS;

    //年龄分布
    private List<PersonStaticsPo> ageDTOS;
}
