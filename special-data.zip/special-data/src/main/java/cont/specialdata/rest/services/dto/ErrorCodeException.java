package cont.specialdata.rest.services.dto;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/21 16:03
 */
/**
 * 带有代号的异常
 */
public class ErrorCodeException extends DomainException implements IErrorCode {
    /**
     * 错误代号
     */
    private String code;

    public ErrorCodeException(String message) {
        super(message);
    }

    public ErrorCodeException(String message, String code) {
        super(message);
        this.code = code;
    }

    public ErrorCodeException(String message, Throwable cause) {
        super(message, cause);
    }

    public ErrorCodeException(String message, Throwable cause, String code) {
        super(message, cause);
        this.code = code;
    }

    public ErrorCodeException(Throwable cause, String code) {
        super(cause);
        this.code = code;
    }

    public ErrorCodeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, String code) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}