package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 10:42
 */
@Data
public class SexRatio {
    //男人数量
    private int manCount;
    //男人比例
    private double manRatio;

    //女人数量
    private int womanCount;

    //女人比例
    private double womanRatio;

}
