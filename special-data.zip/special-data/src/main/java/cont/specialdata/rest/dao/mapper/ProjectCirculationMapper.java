package cont.specialdata.rest.dao.mapper;

import cont.specialdata.rest.dao.po.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 13:06
 */
@Mapper
public interface ProjectCirculationMapper {

    /**
     * 添加用户
     *
     * @param userDTO 用户信息
     */
    void addUser(UserPo userDTO);

    /**
     * 编辑用户
     *
     * @param userDTO 用户信息
     */
    void editUser(UserPo userDTO);

    /**
     * 删除用户
     *
     * @param userId 用户id
     */
    void deleteUser(String userId);

    /**
     * 根据用户名称查询用户
     *
     * @param name 用户单位
     */
    List<UserPo> selectUserByName(String name);

    /**
     * 根据用户Id查询用户
     *
     * @param id 单位Id
     */
    UserPo  selectUserById(String id);


    /**
     * 根据id查询项目
     *
     * @param id 项目Id
     */
    ProjectPo selectProjectById(String id);
    /**
     * 根据项目名称查询用户
     *
     * @param name 项目名称
     */
    List<ProjectPo> selectProjectByName(String name);


    /**
     * 添加项目
     *
     * @param projectDTO 项目信息
     */
    void addProject(ProjectPo projectDTO);


    /**
     * 编辑项目
     *
     * @param projectDTO 项目信息
     */
    void editProject(ProjectPo projectDTO);

    /**
     * 删除项目
     *
     * @param projectId 项目id
     */
    void deleteProject(String projectId);

    /**
     * 根据条件查询用户信息
     *
     */
    List<UserPo> getUserPage(@Param("name")String name,@Param("phoneNumber")String phoneNumber,@Param("pageIndex")int pageIndex,@Param("pageSize")int pageSize);
    long getUserCount(@Param("name")String name,@Param("phoneNumber")String phoneNumber);

    /**
     * 根据条件查询项目信息
     *
     */
    List<ProjectDetialPo> getProjectPage(@Param("projectName")String projectName,@Param("userName")String userName,@Param("pageIndex")int pageIndex,@Param("pageSize")int pageSize);

    long getProjectCount(@Param("projectName")String projectName,@Param("userName")String userName);

    /**
     * 根据条件查询报告信息
     *
     */
    List<ReportPo> getReportPage(@Param("type")String type, @Param("state")int state,@Param("userName")String userName,@Param("sampleNo")String sampleNo,@Param("reportName")String reportName,@Param("pageIndex")int pageIndex,@Param("pageSize")int pageSize);

    long getReportCount(@Param("type")String type, @Param("state")int state,@Param("userName")String userName,@Param("sampleNo")String sampleNo,@Param("reportName")String reportName);

    /**
     * 根据数据类型获取代码表
     */
    List<CodeItemPo> getCodeItem(String type);

    /**
     * 获取单位名称
     */
    List<String> getUnitName(@Param("name")String name);

    /**
     * 添加报告
     *
     * @param reportDTO 报告信息
     */
    void addReport(AddReportPo reportDTO);

    /**
     * 编辑报告
     *
     * @param editReportDTO 报告信息
     */
    void editReport(EditReportPo editReportDTO);

    /**
     * 删除报告
     *
     */
    void deleteReport(String reportId);

    /**
     * 上报报告
     *
     */
    void report(@Param("reportId")String reportId,@Param("date")Date date);

    /**
     * 交接报告
     *
     */
    void handover(@Param("reportId")String reportId,@Param("date")Date date);

    /**
     * 统计一周的报告
     */
    List<ReportPo> statisticsWeek(@Param("beginDate")Date beginDate,@Param("endDate")Date endDate);

    /**
     * 获取项目名称
     */
    List<String> getProjectName(@Param("name")String name,@Param("entrustedUnit")String entrustedUnit);


    /**
     * 更新项目的单位名称
     */
    void updateProjectUserName(@Param("sourceName")String sourceName,@Param("targetName")String targetName);

    /**
     * 更新报告的单位名称
     */
    void updateReportUserName(@Param("sourceName")String sourceName,@Param("targetName")String targetName);

    /**
     * 更新报告的项目名称
     */
    void updateReportProjectName(@Param("sourceName")String sourceName,@Param("targetName")String targetName);

    /**
     * 根据Id查询报告详细信息
     */
    ReportPo getReportById(String id);

    /**
     * 根据项目Id查询报告信息
     */
     List<ReportPo> getReportByProjectId(String projectId);

    long getOutboundNoByType(@Param("type")String type,@Param("beginDate")Date beginDate,@Param("endDate")Date endDate);

    /**
     * 领取
     */
    void recipient(@Param("reportId")String reportId,@Param("recipient")String recipient,@Param("recipientTime")Date recipientTime);

    /**
     * 根据出站号查询报告信息
     */
    List<ReportPo> getReportByOutboundNo(@Param("outboundNo")String outboundNo,@Param("beginDate")Date beginDate,@Param("endDate")Date endDate);
}
