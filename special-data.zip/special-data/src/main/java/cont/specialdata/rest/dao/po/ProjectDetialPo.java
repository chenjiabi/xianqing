package cont.specialdata.rest.dao.po;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 17:49
 */
@Data
public class ProjectDetialPo {
    private String id;


    private String projectName;

    private String owner;

    private String leader;

    private short rate;

    private String remark;

    private int currentProgress;
}
