package cont.specialdata.rest.services.dto;

import lombok.Data;

import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 10:16
 */
@Data
public class DaPingTopInFoDTO {

    //参赛总人数
    private int canSaiCount;

    //确认参赛人数
    private int canSaiQueRenCount;

    //参赛总单位
    private int canSaiDanWeiCount;
    //竞赛项目数量
    private int jingSaiXiangMuCount;

    //竞赛平台数量
    private int jingSaiPingTaiCount;

}
