package cont.specialdata.rest.services.dto;

import lombok.Data;

import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 11:02
 */
@Data
public class DaPingBottomInFoDTO {
    //省份及数量
   private List<ProvinceDTO> provinceDTOS;

    //代表队数量
    private int daiBiaoDuiCount;


}
