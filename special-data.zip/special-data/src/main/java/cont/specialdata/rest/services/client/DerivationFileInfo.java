package cont.specialdata.rest.services.client;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 9:51
 */
@Data
public class DerivationFileInfo {
    private String id;
    /**
     * 文件ID
     */
    private String materialId;
    /**
     * 产品类别（缩略图、预览文件）
     */
    private String type;
    /**
     * 衍生产品文件ID
     */
    private String derivationMaterialId;
}
