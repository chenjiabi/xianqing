package cont.specialdata.rest.services.client;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 9:53
 */
@Data
@AllArgsConstructor
public class OSSClientProperty {

    /***
     * 远程oss根地址
     */
    private String rootUrl;
    /***
     * 项目名称
     */
    private String project;

    private String appid;

    private String appsecret;
}
