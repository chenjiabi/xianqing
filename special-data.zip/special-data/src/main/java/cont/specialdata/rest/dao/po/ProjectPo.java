package cont.specialdata.rest.dao.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 14:13
 */
@Data
public class ProjectPo {
    private String id;


    private String projectName;

    private String owner;

    private String leader;

    private short rate;

    private String remark;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
}
