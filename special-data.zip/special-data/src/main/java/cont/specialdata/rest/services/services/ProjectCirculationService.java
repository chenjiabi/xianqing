package cont.specialdata.rest.services.services;

import cont.specialdata.rest.services.dto.CommonPage;
import cont.specialdata.rest.services.dto.projectDTO.*;
import io.swagger.annotations.ApiParam;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 13:05
 */
public interface ProjectCirculationService {
    /**
     * 添加用户
     *
     * @param userDTO 用户信息
     */
     String addUser(UserDTO userDTO);

    /**
     * 编辑用户
     *
     * @param userDTO 用户信息
     */
     String editUser(UserDTO userDTO);

    /**
     * 删除用户
     *
     * @param userId 用户id
     */
     String deleteUser(String userId);


    /**
     * 添加项目
     *
     * @param projectDTO 项目信息
     */
     String addProject(ProjectDTO projectDTO);


    /**
     * 编辑项目
     *
     * @param projectDTO 项目信息
     */
     String editProject(ProjectDTO projectDTO);

    /**
     * 删除项目
     *
     * @param projectId 项目id
     */
     String deleteProject(String projectId);

    /**
     * 添加报告
     *
     * @param reportDTO 报告信息
     */
     String addReport(AddReportDTO reportDTO);

    /**
     * 编辑报告
     *
     * @param editReportDTO 报告信息
     */
     String editReport(EditReportDTO editReportDTO);

    /**
     * 根据条件查询用户信息
     *
     */
     CommonPage<UserDTO> getUserPage(String name, String phoneNumber, int pageIndex, int pageSize);

    /**
     * 根据条件查询项目信息
     *
     */
     CommonPage<ProjectDetialDTO> getProjectPage(String projectName, String userName, int pageIndex, int pageSize);

    /**
     * 根据数据类型获取代码表
     */
     List<CodeItem> getCodeItem(String type);

    /**
     * 获取单位名称
     */
     List<String> getUnitName(String name);

    /**
     * 删除报告
     *
     */
     void deleteReport(String reportId);

    /**
     * 上报报告
     *
     */
     void report(String reportId);

    /**
     * 交接报告
     *
     */
     void handover(String reportId);

    /**
     * 根据条件查询报告信息
     */
     CommonPage<ReportDTO> getReportPage(String type, int state,String userName,String sampleNo,String reportName, int pageIndex, int pageSize);

    /**
     * 统计一周的报告
     */
     List<WeekReportDTO> statisticsWeek(Date beginDate);

    /**
     * 获取项目名称
     */
     List<String> getProjectName(String name,String entrustedUnit);

    /**
     * 根据Id查询报告详细信息
     */
      ReportDTO getReportById(String id);

    /**
     * 根据项目Id查询报告信息
     */
     List<ReportDTO> getReportByProjectId(String projectId);

    /**
     * 根据类型获取出站号
     */
     String getOutboundNoByType(String type);

    /**
     * 领取
     */
     void recipient(String reportId,String recipient);

    /**
     * 导出报告
     */
     ByteArrayOutputStream exportReport(String type, int state, String userName, String sampleNo, String reportName)  throws IOException;
}
