package cont.specialdata.rest.util;

import cont.specialdata.rest.services.client.FileContent;
import org.apache.poi.util.IOUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2022/1/4 12:15
 */
public abstract class ExcelExportBaseController {
    protected void writeStreamToResponse(HttpServletResponse response, ByteArrayOutputStream stream, String fileName) throws IOException {
        try {
            fileName = URLEncoder.encode(fileName, "UTF-8");
            fileName = new String(fileName.getBytes("utf-8"), "ISO-8859-1");
            // 配置文件下载
            response.setHeader("content-type", "application/octet-stream");
            response.setContentType("application/octet-stream");
            //设置Http响应头告诉浏览器下载这个附件
            response.setHeader("Content-Disposition", "attachment;Filename=" + fileName + ".xls");
            OutputStream outputStream = response.getOutputStream();
            outputStream.write(stream.toByteArray());
            outputStream.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new IOException("导出Excel出现严重异常，异常信息：" + ex.getMessage(), ex);
        }
    }

    protected void writeStreamToResponseTxt(HttpServletResponse response, ByteArrayOutputStream stream, String fileName) throws IOException {
        try {
            fileName = URLEncoder.encode(fileName, "UTF-8");
            fileName = new String(fileName.getBytes("utf-8"), "ISO-8859-1");
            fileName = fileName.replaceAll("\\+", "%20");

            // 配置文件下载
            response.setHeader("content-type", "application/octet-stream");
            response.setContentType("application/octet-stream");
            //设置Http响应头告诉浏览器下载这个附件
            response.setHeader("Content-Disposition", "attachment;Filename=" + fileName + ".txt");
            OutputStream outputStream = response.getOutputStream();
            outputStream.write(stream.toByteArray());
            outputStream.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new IOException("导出txt出现严重异常，异常信息：" + ex.getMessage(), ex);
        }
    }

    protected void writeStreamToResponseByFileName(HttpServletResponse response, FileContent fileContent) throws IOException {
        InputStream stream = fileContent.getFileStream();
        String fileName = fileContent.getFileName();
        try {
            fileName = URLEncoder.encode(fileName, "UTF-8");
            fileName = new String(fileName.getBytes("utf-8"), "ISO-8859-1");
            String lowerCaseStr = fileName.toLowerCase();
            //获得输出流
            String contentType = "application/octet-stream";
            if (lowerCaseStr.endsWith(".png")) {
                contentType = "image/png";
            } else if (lowerCaseStr.endsWith(".doc")) {
                contentType = "application/msword";
            } else if (lowerCaseStr.endsWith(".jpg")) {
                contentType = "image/jpeg";
            } else if (lowerCaseStr.endsWith(".txt")) {
                contentType = "text/plain";
            } else if (lowerCaseStr.endsWith(".pdf")) {
                contentType = "application/pdf";
            } else if (lowerCaseStr.endsWith(".docx")) {
                contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            } else if (lowerCaseStr.endsWith(".xls")) {
                contentType = "application/vnd.ms-excel";
            } else if (lowerCaseStr.endsWith(".xlsx")) {
                contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            }
            // 配置文件下载
            response.setHeader("content-type", contentType);
            response.setContentType(contentType);
            //设置Http响应头告诉浏览器下载这个附件
            response.setHeader("Content-Disposition", "attachment;Filename=" + fileName);
            OutputStream outputStream = response.getOutputStream();

            //文件拷贝标准代码
            IOUtils.copy(stream, outputStream);
            //关闭输入流，输出流会自动关闭。
            stream.close();
            outputStream.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new IOException("导出txt出现严重异常，异常信息：" + ex.getMessage(), ex);
        }
    }
}

