package cont.specialdata.rest.controller;

import cont.specialdata.rest.services.dto.CommonPage;
import cont.specialdata.rest.services.dto.CommonResult;
import cont.specialdata.rest.services.dto.projectDTO.*;
import cont.specialdata.rest.services.services.ProjectCirculationService;
import cont.specialdata.rest.util.ExcelExportBaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 13:04
 */
@RestController
@Api(tags = "项目流转", description = "ProjectCirculationController")
@RequestMapping("/projectcirculation")
public class ProjectCirculationController extends ExcelExportBaseController {

    @Autowired
    private ProjectCirculationService projectCirculationService;


    @ApiOperation("添加用户")
    @RequestMapping(path = "/addUser", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult<String> addUser(@RequestBody @Validated UserDTO userDTO) {
        return CommonResult.success(projectCirculationService.addUser(userDTO));
    }

    @ApiOperation("编辑用户")
    @RequestMapping(path = "/editUser", method = RequestMethod.PUT)
    @ResponseBody
    public CommonResult<String> editUser(@RequestBody @Validated UserDTO userDTO) {
        projectCirculationService.editUser(userDTO);
        return CommonResult.success("编辑用户成功");
    }

    @ApiOperation("删除用户")
    @RequestMapping(path = "/deleteUser", method = RequestMethod.DELETE)
    @ResponseBody
    public CommonResult<String> deleteUser(@RequestParam(value = "userId", required = true) String userId) {
        projectCirculationService.deleteUser(userId);
        return CommonResult.success("删除成功");
    }


    @ApiOperation("添加项目")
    @RequestMapping(path = "/addProject", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult<String> addProject(@RequestBody @Validated ProjectDTO projectDTO) {
        return CommonResult.success(projectCirculationService.addProject(projectDTO));
    }

    @ApiOperation("编辑项目")
    @RequestMapping(path = "/editProject", method = RequestMethod.PUT)
    @ResponseBody
    public CommonResult<String> editProject(@RequestBody @Validated ProjectDTO projectDTO) {
        projectCirculationService.editProject(projectDTO);
        return CommonResult.success("编辑项目成功");
    }

    @ApiOperation("删除项目")
    @RequestMapping(path = "/deleteProject", method = RequestMethod.DELETE)
    @ResponseBody
    public CommonResult<String> deleteProject(@RequestParam(value = "projectId", required = true) String projectId) {
        projectCirculationService.deleteProject(projectId);
        return CommonResult.success("删除项目成功");
    }


    @ApiOperation("根据条件分页查询用户信息")
    @RequestMapping(path = "/pageUser", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<CommonPage<UserDTO>> getUserPage(@ApiParam(name = "name", value = "名称") @RequestParam(value = "name", required = false, defaultValue = "") String name,
                                                              @ApiParam(name = "phoneNumber", value = "电话") @RequestParam(value = "phoneNumber", required = false) String phoneNumber,
                                                              @ApiParam(name = "pageIndex", value = "页码") @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                              @ApiParam(name = "pageSize", value = "每页条数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        return CommonResult.success(projectCirculationService.getUserPage(name, phoneNumber,pageIndex, pageSize));
    }

    @ApiOperation("根据条件分页查询项目信息")
    @RequestMapping(path = "/pageProject", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<CommonPage<ProjectDetialDTO>> getProjectPage(@ApiParam(name = "projectName", value = "项目名称") @RequestParam(value = "projectName", required = false, defaultValue = "") String projectName,
                                                                  @ApiParam(name = "owner", value = "业主单位名称") @RequestParam(value = "owner", required = false) String owner,
                                                                  @ApiParam(name = "pageIndex", value = "页码") @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                  @ApiParam(name = "pageSize", value = "每页条数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        return CommonResult.success(projectCirculationService.getProjectPage(projectName, owner,pageIndex, pageSize));
    }

    @ApiOperation("根据条件分页查询报告信息")
    @RequestMapping(path = "/pageReport", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<CommonPage<ReportDTO>> pageReport(@ApiParam(name = "type", value = "报告类型") @RequestParam(value = "type", required = false, defaultValue = "") String type,
                                                                     @ApiParam(name = "state", value = "报告状态") @RequestParam(value = "state", required = false,defaultValue = "9") int state,
                                                                   @ApiParam(name = "entrustedUnit", value = "业主单位名称") @RequestParam(value = "entrustedUnit", required = false) String entrustedUnit,
                                                                   @ApiParam(name = "sampleNo", value = "报告编号") @RequestParam(value = "sampleNo", required = false) String sampleNo,
                                                          @ApiParam(name = "reportName", value = "报告名称") @RequestParam(value = "reportName", required = false) String reportName,
                                                                     @ApiParam(name = "pageIndex", value = "页码") @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                     @ApiParam(name = "pageSize", value = "每页条数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        return CommonResult.success(projectCirculationService.getReportPage(type,state, entrustedUnit,sampleNo,reportName,pageIndex, pageSize));
    }

    @ApiOperation("根据Id查询报告详情")
    @RequestMapping(path = "/getReportById", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<ReportDTO> getReportById(@ApiParam(name = "id", value = "报告Id") @RequestParam(value = "id", required = true) String id) {
        return CommonResult.success(projectCirculationService.getReportById(id));
    }


    /**
     * 根据代码类型查询代码表
     */
    @ApiOperation("根据代码类型查询代码表")
    @RequestMapping(path = "/getCodeItem", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<CodeItem>> getCodeItem(@RequestParam(value = "type", required = true)  String type) {
        return CommonResult.success(projectCirculationService.getCodeItem(type));
    }

    @ApiOperation("查询单位名称")
    @RequestMapping(path = "/getUnitName", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<String>> getUnitName(@ApiParam(name = "name", value = "单位名称") @RequestParam(value = "name", required = false, defaultValue = "") String name) {
        return CommonResult.success(projectCirculationService.getUnitName(name));
    }

    @ApiOperation("查询项目名称")
    @RequestMapping(path = "/getProjectName", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<String>> getProjectName(@ApiParam(name = "name", value = "项目名称") @RequestParam(value = "name", required = false, defaultValue = "") String name,
                                                     @ApiParam(name = "entrustedUnit", value = "单位名称") @RequestParam(value = "entrustedUnit", required = false, defaultValue = "") String entrustedUnit) {
        return CommonResult.success(projectCirculationService.getProjectName(name,entrustedUnit));
    }

    @ApiOperation("添加报告")
    @RequestMapping(path = "/addReport", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult<String> addReport(@RequestBody @Validated AddReportDTO reportDTO) {
        return CommonResult.success(projectCirculationService.addReport(reportDTO));
    }

    @ApiOperation("编辑报告")
    @RequestMapping(path = "/editReport", method = RequestMethod.PUT)
    @ResponseBody
    public CommonResult<String> editReport(@RequestBody @Validated EditReportDTO editReportDTO) {
        projectCirculationService.editReport(editReportDTO);
        return CommonResult.success("编辑报告成功");
    }

    @ApiOperation("删除报告")
    @RequestMapping(path = "/deleteReport", method = RequestMethod.DELETE)
    @ResponseBody
    public CommonResult<String> deleteReport(@RequestParam(value = "reportId", required = true) String reportId) {
        projectCirculationService.deleteReport(reportId);
        return CommonResult.success("删除报告成功");
    }


    @ApiOperation("上报")
    @RequestMapping(path = "/report", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<String> report(@RequestParam(value = "reportId", required = true) String reportId) {
        projectCirculationService.report(reportId);
        return CommonResult.success("上报成功");
    }

    @ApiOperation("交接")
    @RequestMapping(path = "/handover", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<String> handover(@RequestParam(value = "reportId", required = true) String reportId) {
        projectCirculationService.handover(reportId);
        return CommonResult.success("交接成功");
    }

    @ApiOperation("统计一周")
    @RequestMapping(path = "/statisticsWeek", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<WeekReportDTO>> statisticsWeek(@RequestParam @ApiParam("开始时间") @DateTimeFormat(pattern = "yyyy-MM-dd") Date beginDate) {
      return CommonResult.success(projectCirculationService.statisticsWeek(beginDate));
    }


    @ApiOperation("根据项目查询报告")
    @RequestMapping(path = "/getReportByProjectId", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<ReportDTO>> getReportByProjectId(@ApiParam(name = "projectId", value = "报告Id") @RequestParam(value = "projectId", required = true) String projectId) {
        return CommonResult.success(projectCirculationService.getReportByProjectId(projectId));
    }

    @ApiOperation("根据类型获取出站号")
    @RequestMapping(path = "/getOutboundNoByType", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<String> getOutboundNoByType(@ApiParam(name = "type", value = "报告类型") @RequestParam(value = "type", required = true) String type) {
        return CommonResult.success(projectCirculationService.getOutboundNoByType(type));
    }

    @ApiOperation("领取")
    @RequestMapping(path = "/reveive", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<String> reveive(@RequestParam(value = "reportId", required = true) String reportId,
                                        @RequestParam(value = "recipient", required = true) String recipient) {
        projectCirculationService.recipient(reportId,recipient);
        return CommonResult.success("领取成功");
    }

    @ApiOperation("导出报告")
    @RequestMapping(path = "/exportReport", method = RequestMethod.GET)
    @ResponseBody
    public void exportReport(@ApiParam(name = "type", value = "报告类型") @RequestParam(value = "type", required = false, defaultValue = "") String type,
                              @ApiParam(name = "state", value = "报告状态") @RequestParam(value = "state", required = false,defaultValue = "9") int state,
                              @ApiParam(name = "entrustedUnit", value = "业主单位名称") @RequestParam(value = "entrustedUnit", required = false) String entrustedUnit,
                              @ApiParam(name = "sampleNo", value = "报告编号") @RequestParam(value = "sampleNo", required = false) String sampleNo,
                              @ApiParam(name = "reportName", value = "报告名称") @RequestParam(value = "reportName", required = false) String reportName
            , HttpServletResponse response) throws IOException {
        ByteArrayOutputStream stream = projectCirculationService.exportReport(type,state,entrustedUnit,sampleNo,reportName);
//        DateFormat formatBegin = new SimpleDateFormat("yyyy-MM-dd");
//        String timeBegin = formatBegin.format(beginDate);
//        String timeEnd = formatBegin.format(endDate);
        String title = "报告列表";
        writeStreamToResponse(response, stream, title);
    }

}
