package cont.specialdata.rest.services.dto.projectDTO;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 14:01
 */
@Data
public class ProjectDTO {
    private String id;


    private String projectName;

    private String owner;

    private String leader;

    private short rate;

    private String remark;
}
