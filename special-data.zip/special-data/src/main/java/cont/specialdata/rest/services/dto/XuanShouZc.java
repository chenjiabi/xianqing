package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 10:47
 */
@Data
public class XuanShouZc {
    //名称
    private String name;
    //人数量
    private int manCount;
    //人比例
    private double manRatio;

}
