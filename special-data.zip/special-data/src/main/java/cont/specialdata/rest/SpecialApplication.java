package cont.specialdata.rest;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;


/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/3/23 10:01
 */
@SpringBootApplication
@ComponentScan(basePackages = {"cont.specialdata.rest.**"})
@MapperScan(value = "cont.specialdata.rest.dao.mapper")
public class SpecialApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpecialApplication.class, args);
    }


}
