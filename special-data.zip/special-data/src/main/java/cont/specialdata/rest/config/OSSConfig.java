package cont.specialdata.rest.config;

import cont.specialdata.rest.services.client.OSSClientProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 10:35
 */
@Data
@Component
@ConfigurationProperties(prefix = "oss")
public class OSSConfig {
    private String appId;
    private String appSecret;
    private String projectName;
    private String url;
    public OSSClientProperty getOSSClientProperty(){
        return new OSSClientProperty(url,projectName,appId,appSecret);
    }
}
