package cont.specialdata.rest.dao.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/22 13:56
 */
@Data
public class EditReportPo {
    private String id;
    private String outboundNo;
    private String provinceNo;
    private short isUpload;
    private String entrustedUnit;
    private String projectName;
    private String sampleNo;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date recieveTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date lastTime;
    private short overProof;
    private String preparedPerson;
    private String auditPerson;
    private String issuer;
    private String recipient;
    private String remark;
    private String realAuditPerson;
    private String realIssuer;
    private String realPreparedPerson;
    private String type;

    private int state;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date reportTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date handoverTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date auditTime;

    private int bigNo;
    private String smallNo;

    private String reportName;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date recipientTime;
}
