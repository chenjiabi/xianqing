package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/21 15:50
 */
@Data
public class Participant {

    private String id;


    private String team;

    private String person_type;

    private String name;

    private String id_number;

    private String sex;

    private int age;

    private String nation;

    private String work_unit;

    private String address;

    private String post_code;

    private String phone_number;
    private String mail_box;


    private String audit_status;

    private String jl;


    private String person_status;

    //疫苗检测凭证ID
    private String ymjzpz;

    //健康码id
    private String jkm;

    //行程码
    private String xcm;

    //核酸检测证明
    private String hsjczm;

    private String ycremark;

    private String qdstatus;

}
