package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/21 21:46
 */
@Data
public class ParticipantBaseInfo {

    private String team;

    private String person_type;

    private String userName;
}
