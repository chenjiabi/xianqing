package cont.specialdata.rest.util;

import cn.hutool.cache.impl.TimedCache;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.http.HttpRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.dozermapper.core.DozerBeanMapperBuilder;
import cont.specialdata.rest.services.dto.DomainException;
import org.apache.http.client.utils.URIBuilder;
import com.github.dozermapper.core.Mapper;
import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 9:59
 */
public class CommonUtil {
    private static TimedCache timedCache;
    private static Mapper mapper = DozerBeanMapperBuilder.buildDefault();
    private static ObjectMapper jsonMapper;

    /**
     * 获取单例dozer映射对象
     *
     * @return
     */
    public static Mapper getMapper() {
        /*if (mapper == null) {
            mapper = DozerBeanMapperBuilder.buildDefault();
        }*/
        return mapper;
    }

    /**
     * 获取单例Json映射对象
     *
     * @return
     */
    public static ObjectMapper getJsonMapper() {
        if (jsonMapper == null) {
            jsonMapper = new ObjectMapper();
        }
        return jsonMapper;
    }

    /**
     * Json序列化
     *
     * @param value
     * @return
     */
    public static String toJson(Object value) {
        try {
            return getJsonMapper().writeValueAsString(value);
        } catch (Exception e) {
            throw new DomainException("json序列化失败", e);
        }
    }

    /**
     * json读取
     *
     * @param json
     * @return
     */
    public static JsonNode parseJsonNode(String json) {
        try {
            return getJsonMapper().readTree(json);
        } catch (Exception e) {
            throw new DomainException("json读取失败", e);
        }
    }


    /**
     * 获取单例缓存库
     *
     * @return
     */
    public static TimedCache getTimedCache() {
        if (timedCache == null) {
            timedCache = cn.hutool.cache.CacheUtil.newTimedCache(0);
        }
        return timedCache;
    }

    /**
     * 获取url地址的构造器
     *
     * @param url
     * @return
     */
    public static URIBuilder getUrlBuilder(String url) {
        URIBuilder uriBuilder;
        try {
            uriBuilder = new URIBuilder(url);
        } catch (Exception e) {
            throw new DomainException("解析Uri地址时失败:" + url);
        }
        return uriBuilder;
    }

    /**
     * 构建三方网关的请求权限信息
     *
     * @param request
     * @param token
     * @param appId
     */
    public static void buildThirdGatewayAuthInfo(HttpRequest request, String token, String appId) {
        //生成5位随机数
        String rand = cn.hutool.core.util.RandomUtil.randomString(5);
        //生成当前时间戳
        long timestamp = System.currentTimeMillis();
        //生成签名
        String sign = SecureUtil.sha1(token + timestamp + rand);
        //设置header
        request.header("sign", sign);
        request.header("timestamp", Long.toString(timestamp));
        request.header("rand", rand);
        request.header("appid", appId);
    }

    /**
     * 生成强密码
     *
     * @param length 密码长度
     */
    public static String randomString(int length) {
        String[] pswdStr = {"qwertyuiopasdfghjklzxcvbnm", "QWERTYUIOPASDFGHJKLZXCVBNM", "0123456789", "~!@#$%^&*()_+{}|<>?:{}"};
        String pswd = " ";
        char[] chs = new char[length];
        for (int i = 0; i < pswdStr.length; i++) {
            int idx = (int) (Math.random() * pswdStr[i].length());
            chs[i] = pswdStr[i].charAt(idx);
        }
        for (int i = pswdStr.length; i < length; i++) {
            int arrIdx = (int) (Math.random() * pswdStr.length);
            int strIdx = (int) (Math.random() * pswdStr[arrIdx].length());
            chs[i] = pswdStr[arrIdx].charAt(strIdx);
        }
        for (int i = 0; i < 1000; i++) {
            int idx1 = (int) (Math.random() * chs.length);
            int idx2 = (int) (Math.random() * chs.length);
            if (idx1 == idx2) {
                continue;
            }
            char tempChar = chs[idx1];
            chs[idx1] = chs[idx2];
            chs[idx2] = tempChar;
        }
        pswd = new String(chs);
        return pswd;
    }

    /**
     * 判断密码强度
     *
     * @param passwordStr 密码
     */
    public static String checkPassword(String passwordStr) {
        String regexZ = "\\d*";
        String regexS = "[a-zA-Z]+";
        String regexT = "\\W+$";
        String regexZT = "\\D*";
        String regexST = "[\\d\\W]*";
        String regexZS = "\\w*";
        String regexZST = "[\\w\\W]*";
        if (passwordStr.matches(regexZ)) {
            return "弱";
        }
        if (passwordStr.matches(regexS)) {
            return "弱";
        }
        if (passwordStr.matches(regexT)) {
            return "弱";
        }
        if (passwordStr.matches(regexZT)) {
            return "中";
        }
        if (passwordStr.matches(regexST)) {
            return "中";
        }
        if (passwordStr.matches(regexZS)) {
            return "中";
        }
        if (passwordStr.matches(regexZST)) {
            return "强";
        }
        return passwordStr;
    }

    /**
     * 获取客户端ip地址
     *
     * @param request
     * @return
     */
    public static String getRemoteIP(HttpServletRequest request) {
        String ipAddress;
        ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.length() == 0
                || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }
        if (ipAddress == null || ipAddress.length() == 0
                || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ipAddress == null || ipAddress.length() == 0
                || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
            if (ipAddress.equals("127.0.0.1")) {
                // 根据网卡取本机配置的IP
                InetAddress inet = null;
                try {
                    inet = InetAddress.getLocalHost();
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                ipAddress = inet.getHostAddress();
            }

        }

        // 对于通过多个代理的情况，第一个IP为客户端真实IP,多个IP按照','分割
        if (ipAddress != null && ipAddress.length() > 15) { // "***.***.***.***".length()
            // = 15
            if (ipAddress.indexOf(",") > 0) {
                ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
            }
        }
        return ipAddress;
    }

    /**
     * 转换对象
     * @param source
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T convert( Object source,  Class<T> clazz) {
        return  mapper.map(source, clazz);
    }

    /**
     * 转换集合
     * @param source
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> List<T> convert(List<?> source, Class<T> clazz) {
        return Optional.ofNullable(source)
                .orElse(Collections.emptyList())
                .stream()
                .map(bean -> mapper.map(bean, clazz))
                .collect(Collectors.toList());
    }

}
