package cont.specialdata.rest.services.dto.projectDTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/22 13:34
 */
@Data
public class EditReportDTO {

    private String id;
    private String outboundNo;
    private String provinceNo;
    private short isUpload;
    private String entrustedUnit;
    private String projectName;
    private String sampleNo;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date recieveTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date lastTime;
    private short overProof;
    private String preparedPerson;
    private String auditPerson;
    private String issuer;
    private String recipient;
    private String remark;
    private String realAuditPerson;
    private String realIssuer;
    private String type;
    private String realPreparedPerson;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date reportTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date handoverTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date auditTime;

    private String reportName;

    private List<String> smallNo;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date recipientTime;
}
