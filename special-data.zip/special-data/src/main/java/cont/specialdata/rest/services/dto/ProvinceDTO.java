package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 11:07
 */
@Data
public class ProvinceDTO {
    //名称
    private String name;
    //人数量
    private int count;
}
