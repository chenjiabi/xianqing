package cont.specialdata.rest.dao.po;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 11:33
 */
@Data
public class MaPo {
    private String id;

    //疫苗检测凭证ID
    private String ymjzpz;

    //健康码id
    private String jkm;

    //行程码
    private String xcm;

    //核酸检测证明
    private String hsjczm;
}
