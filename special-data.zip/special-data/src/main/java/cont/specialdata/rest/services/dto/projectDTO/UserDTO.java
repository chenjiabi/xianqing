package cont.specialdata.rest.services.dto.projectDTO;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 13:50
 */
@Data
public class UserDTO {
    private String id;


    private String name;

    private String contactUser;

    private String phoneNumber;

    private String area;

    private String operatingPerson;

    private String address;

    private String postCode;

    private String remark;

    private String director;
}
