package cont.specialdata.rest.util;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
/**
 * @author chenjiabin
 * @version 1.0
 * @date 2022/1/4 12:08
 */
public class ExcelExportUtil {

    //excel表对象
    private Workbook workbook;
    //工作表对象
    private Sheet sheet;
    //标题
    private String title;
    //sheet各个列的表头
    private String[] headList;
    //sheet需要填充的数据信息
    private List<List<Object>> data;
    //sheet需要填充的数据信息
    private List<String> data1;
    //工作表名称
    private String sheetName = "sheet1";
    //工作表列宽
    private Integer columnWidth = 20;
    //工作表行高
    private Integer rowHeight = 12;

    public String getSheetName() {
        return sheetName;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public Integer getColumnWidth() {
        return columnWidth;
    }

    public void setColumnWidth(Integer columnWidth) {
        this.columnWidth = columnWidth;
    }

    public Integer getRowHeight() {
        return rowHeight;
    }

    public void setRowHeight(Integer rowHeight) {
        this.rowHeight = rowHeight;
    }

    public Workbook getWorkbook() {
        return workbook;
    }

    public void setWorkbook(Workbook workbook) {
        this.workbook = workbook;
    }

    public Sheet getSheet() {
        return sheet;
    }

    public void setSheet(Sheet sheet) {
        this.sheet = sheet;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String[] getHeadList() {
        return headList;
    }

    public void setHeadList(String[] headList) {
        this.headList = headList;
    }

    public List<List<Object>> getData() {
        return data;
    }

    public void setData(List<List<Object>> data) {
        this.data = data;
    }

    /**
     * 将数据写入Excel内存流
     *
     * @param data
     * @param excelExport2
     * @param mainStartRow 正文开始位置
     * @param mainStartRow 正文字体大小
     * @return
     * @throws IOException
     */
    public static ByteArrayOutputStream writeToOutputStream(List<List<Object>> data, ExcelExportUtil excelExport2,
                                                            int mainStartRow, int mainFontsize) throws IOException {
        excelExport2.setData(data);


        excelExport2.writeMainData(mainStartRow, mainFontsize);
        //写入到流对象
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        excelExport2.getWorkbook().write(outputStream);
        return outputStream;
    }

    /**
     * @return *
     * @Author
     * @Description //TODO 表头样式
     * @Date 2020/3/19 14:30
     * @Param
     */
    public  CellStyle getHeadStyle(Workbook wb, int fontSize) {
        CellStyle cellStyle = wb.createCellStyle();
        cellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
        addBorder(cellStyle);
        cellStyle.setWrapText(true);
        //设置字体
        //设置字体
        Font font = wb.createFont();
        font.setFontHeightInPoints((short) fontSize);
        font.setFontName("宋体");
        cellStyle.setFont(font);
        return cellStyle;
    }


    /**
     * @return *
     * @Author
     * @Description 插入数据到表格（body）
     * @Date 2019/7/26 17:28
     * @Param startRow: 开始插入数据的行
     */
    public void writeMainData(Integer startRow,Integer fontSize) throws IOException {
        checkConfig();
        //开始写入实体数据信息
        CellStyle cellStyle = ExcelStyleUtilFor2003.getBodyStyle(this.workbook, fontSize);
        addBorder(cellStyle);
        if (data.size() > 0 && null != data.get(0)) {
            for (int i = 0; i < data.size(); i++) {
                Row row = this.sheet.createRow(startRow);
                row.setHeightInPoints(this.rowHeight);
                List<Object> colItems = data.get(i);
                for (int j = 0; j < headList.length; j++) {
                    Cell cell = row.createCell(j);
                    cellStyle.setWrapText(true);
                    cell.setCellStyle(cellStyle);

                    Object value = colItems.get(j);
                    if (null == value) {
                        String valueN = "";
                        cell.setCellValue(valueN);
                    } else if (value instanceof Integer) {
                        Integer valueInt = Integer.valueOf(value.toString());
                        cell.setCellValue(valueInt);
                    } else if (value instanceof String) {
                        String valueStr = String.valueOf(value);
                        cell.setCellValue(valueStr);
                    } else if (value instanceof Double) {
                        cell.setCellValue((Double)(value));
                    } else if (value instanceof Date) {
                        cell.setCellValue((Date)(value));
                    }else{
                        cell.setCellValue(value.toString());
                    }
                }
                startRow++;
            }
        }


    }


    /**
     * @return * @param null
     * @Author
     * @Description 添加表格标题
     * @Date 2019/7/26 17:58
     * @Param
     */
    public void writeTitle(Integer titleRowHeight,Integer fontSize) throws IOException {
        checkConfig();
        //设置默认行宽
        this.sheet.setDefaultColumnWidth(20);
        //在第0行创建rows  (表标题)
        Row title = this.sheet.createRow(0);
        title.setHeightInPoints(titleRowHeight);//行高
        Cell cell = title.createCell(0);
        cell.setCellValue(this.title);
        CellStyle cellStyle = ExcelStyleUtilFor2003.getTitleStyle(this.workbook, true, fontSize);
        Font font = this.workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 20);
        font.setFontName("宋体");
        cellStyle.setFont(font);
        cell.setCellStyle(cellStyle);
        addBorder(cellStyle);
        ExcelStyleUtilFor2003.mergeCell(sheet, 0, 0, 0, (this.headList.length - 1));
    }
    /**
     * @return * @param null
     * @Author
     * @Description 添加边框
     * @Date 2019/7/26 17:58
     * @Param cellStyle
     */
    public void addBorder(CellStyle cellStyle)
    {
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
    }


    /**
     * @return *
     * @Author
     * @Description 添加表头
     * @Date 2019/7/26 15:41
     * @Param headRowNum: 添加表头所在行数
     */
    public void writeTableHead( CellStyle cellStyle, Integer headRowNum,Integer headRowHeight) throws IOException {
        checkConfig();

        Row row = this.sheet.createRow(headRowNum);
        row.setHeightInPoints(headRowHeight);
        if (this.headList.length > 0) {

            for (int i = 0; i < this.headList.length; i++) {
/*                int width=this.headList[i].length();
                if(width>6)
                {
                    sheet.setColumnWidth(i,256*14);
                    row.setHeightInPoints(headRowHeight*2);
                }
              else if(width>3)
                {
                    sheet.setColumnWidth(i,256*3*width);
                }
              else
                {
                    sheet.setColumnWidth(i,256*4*width);
                }*/
                Cell cell = row.createCell(i);
                cell.setCellValue(this.headList[i]);
                cell.setCellStyle(cellStyle);
            }
        }
    }
    public void setColumnWidth (int i, int width)throws IOException {
        if (this.workbook == null) {
            this.workbook = new HSSFWorkbook();
        }
        if (this.sheet == null) {
            this.sheet = this.workbook.createSheet(this.sheetName);
        }
        this.sheet.setColumnWidth(i, width);
    }


    /**
     * 检查数据配置问题
     *
     * @throws IOException 抛出数据异常类
     */
    protected void checkConfig() throws IOException {
        if (headList == null || headList.length == 0) {
            throw new IOException("列名数组不能为空或者为NULL");
        }
        if (this.workbook == null) {
            this.workbook = new HSSFWorkbook();
        }
        if (this.sheet == null) {
            this.sheet = this.workbook.createSheet(this.sheetName);
        }
    }

}
