package cont.specialdata.rest.services.client;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.InputStream;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 9:53
 */
@Data
@AllArgsConstructor
public class FileContent {
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 文件字节流
     */
    private InputStream fileStream;
}