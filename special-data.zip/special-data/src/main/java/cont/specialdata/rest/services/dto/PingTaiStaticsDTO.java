package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 10:53
 */
@Data
public class PingTaiStaticsDTO {
    //名称
    private String name;
    //人数量
    private int count;

    //确认数量
    private int queRenCount;
}
