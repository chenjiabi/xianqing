package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 10:33
 */
@Data
public class FileDTO {

    /**
     * 文件名
     */
    private  String fileName;
    /**
     * 文件ID
     */
    private  String id;
    /**
     * 文件扩展名
     */
    private  String extension;
}
