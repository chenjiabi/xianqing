package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/21 21:54
 */
@Data
public class StaticsDetailDTO {
    private long allCount;

    private long confirmedCount;

    private long noConfirmedCount;

    private long xsCount;

    private long jlCount;
}
