package cont.specialdata.rest.services.client;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 9:52
 */
@Data
@NoArgsConstructor
public class FileBytesResponse {
    /***
     * id
     */
    private String id;
    /***
     * 在线url地址
     */
    private String url;
    /**
     * 存储路径名称
     */
    private String store;

    private String originalName;

    private String objType;

    private Long byteLength;

    private String byteToStr;
}
