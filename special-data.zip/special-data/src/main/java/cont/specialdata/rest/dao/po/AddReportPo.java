package cont.specialdata.rest.dao.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 20:55
 */
@Data
public class AddReportPo {
    private String id;


    private String outboundNo;

    private String provinceNo;
    private short isUpload;
    private String entrustedUnit;
    private String projectName;

    private String sampleNo;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date recieveTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date lastTime;

    private short overProof;

    private String preparedPerson;

    private String auditPerson;

    private String issuer;

    private String recipient;

    private String remark;

    private String type;

    private String realPreparedPerson;

    private int state;

    private int bigNo;
    private String smallNo;

    private String reportName;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
}
