package cont.specialdata.rest.dao.po;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/21 20:01
 */
@Data
public class CodeItemPo {
    private String id;


    private String name;

    private String type;

    private String code;

    private int orderNo;
}
