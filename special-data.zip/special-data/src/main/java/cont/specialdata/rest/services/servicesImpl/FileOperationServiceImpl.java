package cont.specialdata.rest.services.servicesImpl;

import cn.hutool.core.io.FileUtil;
import cont.specialdata.rest.config.OSSConfig;
import cont.specialdata.rest.services.client.DerivationFileInfo;
import cont.specialdata.rest.services.client.FileBytesResponse;
import cont.specialdata.rest.services.client.FileContent;
import cont.specialdata.rest.services.client.OSSClient;
import cont.specialdata.rest.services.dto.CommonResult;
import cont.specialdata.rest.services.dto.DomainException;
import cont.specialdata.rest.services.dto.FileDTO;
import cont.specialdata.rest.services.services.FileOperationService;
import org.apache.commons.io.IOUtils;
import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 10:10
 */
@Service
public class FileOperationServiceImpl implements FileOperationService {

    @Autowired
    OSSConfig ossConfig;

    /**
     * 根据文件名输出类型
     *
     * @param fileName
     * @return
     */
    private String getContentType(String fileName) {
        String fileNameLower = fileName.toLowerCase();
        if (fileNameLower.endsWith(".png")) {
            return "image/png";
        }
        if (fileNameLower.endsWith(".doc")) {
            return "application/msword";
        }
        if (fileNameLower.endsWith(".jpg")) {
            return "image/jpeg";
        }
        if (fileNameLower.endsWith(".txt")) {
            return "text/plain";
        }
        if (fileNameLower.endsWith(".pdf")) {
            return "application/pdf";
        }
        if (fileNameLower.endsWith(".docx")) {
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        }
        if (fileNameLower.endsWith(".xls")) {
            return "application/vnd.ms-excel";
        }
        if (fileNameLower.endsWith(".xlsx")) {
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
        return "application/octet-stream";
    }

    /**
     * 输出文件
     *
     * @param response
     */
    public void responseStream(FileContent fileContent, HttpServletResponse response) {
        InputStream inputStream = fileContent.getFileStream();
        String fileName = fileContent.getFileName();
        try {
            fileName = URLEncoder.encode(fileName, "UTF-8");
            fileName = new String(fileName.getBytes("utf-8"), "ISO-8859-1");
            String contentType = this.getContentType(fileName);
            // 配置文件下载
            response.setHeader("content-type", contentType);
            response.setContentType(contentType);
            //设置Http响应头告诉浏览器下载这个附件
            response.setHeader("Content-Disposition", "attachment;Filename=" + fileName);
            OutputStream outputStream = response.getOutputStream();
            //输出流
            IOUtils.copy(inputStream, outputStream);
            //关闭输入流，输出流会自动关闭。
            inputStream.close();
            outputStream.close();
        } catch (Exception ex) {
            throw new DomainException(ex.getMessage());
        }
    }

    /**
     * 上传文件
     *
     * @param multipartFile
     * @return
     */
    public synchronized CommonResult<FileDTO> uploadFile(MultipartFile multipartFile) {
        try {
            OSSClient ossClient = this.getOSSClient();
            //使用流上传文件
            FileBytesResponse fileBytesResponse = ossClient
                    .uploadFileByForm(multipartFile.getInputStream(), ContentType.create(multipartFile.getContentType()), multipartFile.getOriginalFilename())
                    .getData(true);
            //结果结果转换
            FileDTO fileDTO = new FileDTO();
            fileDTO.setId(fileBytesResponse.getId());
            fileDTO.setFileName(fileBytesResponse.getOriginalName());
            fileDTO.setExtension(FileUtil.extName(fileBytesResponse.getOriginalName()));
            return CommonResult.success(fileDTO);
        } catch (Exception e) {
            throw new DomainException(e.getMessage());
        }
    }


    /**
     * 下载文件
     *
     * @param fileId
     * @param fileName
     * @return
     */
    public FileContent getFileById(String fileId, String fileName) {
        FileContent fileContent = this.getOSSClient().downFile(fileId);
        fileContent.setFileName(fileName);
        return fileContent;
    }


    /**
     * 下载文件的衍射产品pdf文件
     *
     * @param fileId
     * @param fileName
     * @return
     */
    public FileContent getPdfFileById(String fileId, String fileName) {
        fileName = fileName.toLowerCase();
        boolean bCreatePdf = fileName.endsWith("doc") || fileName.endsWith("docx")
                || fileName.endsWith("ppt") || fileName.endsWith("pptx")
                || fileName.endsWith("xls") || fileName.endsWith("xlsx") || fileName.endsWith("pdf");
        if (!bCreatePdf) {
            return null;
        }
        OSSClient ossClient = this.getOSSClient();
        FileContent fileContent;
        //如果是pdf直接输出预览
        if (fileName.endsWith("pdf")) {
            fileContent = ossClient.downFile(fileId);
            fileContent.setFileName(fileName);
            return fileContent;
        }
        DerivationFileInfo derivationFileInfo = ossClient.getDerivationFileInfo(fileId, "预览文件");
        String pdfId = derivationFileInfo.getDerivationMaterialId();
        fileContent = ossClient.downFile(pdfId);
        fileContent.setFileName(fileName);
        return fileContent;
    }

    /**
     * 生成数据库中文件的 缩略图
     *
     * @param id 数据库中文件id
     * @return 转换成功后的文件id，为空时表示不支持
     */
    public String buildThumbnail(String id) {
        OSSClient ossClient = this.getOSSClient();
        return ossClient.buildThumbnail(id);
    }

    /**
     * 上传图片
     * @param inputStream 文件流
     * @param fileName  文件名
     * @param contentType 文件类型
     * @return
     */
    @Override
    public synchronized CommonResult<FileDTO> uploadFile(InputStream inputStream, String fileName, String contentType) {
        try {
            OSSClient ossClient = this.getOSSClient();
            //使用流上传文件
            FileBytesResponse fileBytesResponse =
                    ossClient.uploadFileByForm(inputStream, ContentType.create(contentType), fileName).getData();
            //结果结果转换
            FileDTO fileDTO = new FileDTO();
            fileDTO.setId(fileBytesResponse.getId());
            fileDTO.setFileName(fileBytesResponse.getOriginalName());
            fileDTO.setExtension(FileUtil.extName(fileBytesResponse.getOriginalName()));
            return CommonResult.success(fileDTO);
        } catch (Exception e) {
            throw new DomainException(e.getMessage());
        }
    }


    /**
     * 创建OSS对象
     *
     * @return
     */
    private OSSClient getOSSClient() {
        OSSClient ossClient = new OSSClient(ossConfig.getOSSClientProperty());
        return ossClient;
    }
}

