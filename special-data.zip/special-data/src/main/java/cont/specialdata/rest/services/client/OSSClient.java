package cont.specialdata.rest.services.client;

import com.fasterxml.jackson.core.type.TypeReference;
import cont.specialdata.rest.services.dto.CommonResult;
import cont.specialdata.rest.services.dto.DomainException;
import cont.specialdata.rest.util.CommonUtil;
import org.apache.http.Header;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.omg.CORBA.UserException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/10/29 9:54
 */
public class OSSClient {
    /***
     * 文件上传
     */
    private static final String UPLOAD_FILE_FORM_API = "/oss/material/uploadMaterialNonProUrl";

    /***
     * 文件下载
     */
    private static final String DOWN_FILE_API = "oss/material/downloadFile";

    /***
     * 获取文件衍生文件信息
     */
    private static final String GET_DERIVATION_FILE_API = "oss/material/getDerivationFileInfo";

    /***
     * 将文件转换为PDF
     */
    private static final String CONVERT_TO_PDF_API = "oss/material/convertToPdf";

    /***
     * 将文件生成缩略图
     */
    private static final String BUILD_THUMBNAIL_API = "oss/material/buildThumbnail";


    private OSSClientProperty ossClientProperty;

    public OSSClient(OSSClientProperty ossClientProperty) {
        this.ossClientProperty = ossClientProperty;
    }

    /**
     * 执行上传文件请求
     *
     * @param request
     * @return
     */
    private CommonResult<FileBytesResponse> executeFileUpload(HttpPost request) {
        CommonResult<List<FileBytesResponse>> result = executeFilesUpload(request);
        CommonResult<FileBytesResponse> fileBytesResponseCommonResult = new CommonResult<>();
        fileBytesResponseCommonResult.setCode(result.getCode());
        fileBytesResponseCommonResult.setMessage(result.getMessage());
        if (result.getData() != null && result.getData().size() > 0) {
            fileBytesResponseCommonResult.setData(result.getData().get(0));
        }
        return fileBytesResponseCommonResult;
    }

    /**
     * 执行文件批量上传
     *
     * @param request
     * @return
     */
    private CommonResult<List<FileBytesResponse>> executeFilesUpload(HttpPost request) {
        CloseableHttpResponse closeableHttpResponse;
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            closeableHttpResponse = httpClient.execute(request);
        } catch (IOException e) {
            throw new DomainException("HTTP请求失败。", e);
        }
        if (closeableHttpResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            throw new DomainException("请求时返回非正常请求代号。");
        }
        String content;
        try {
            content = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
        } catch (IOException e) {
            throw new DomainException("获取HTTP请求结果失败。", e);
        }
        CommonResult<List<FileBytesResponse>> result;
        try {
            result = CommonUtil.getJsonMapper().readValue(content, new TypeReference<CommonResult<List<FileBytesResponse>>>() {
            });
        } catch (Exception e) {
            throw new DomainException("返回结果JSON格式不正确。", e);
        }
        return result;
    }

    /***
     * form表单提交
     * @param file
     * @return
     */
    public CommonResult<FileBytesResponse> uploadFileByForm(File file) {
        FileBody fileBody = new FileBody(file);
        InputStream inputStream;
        try {
            inputStream = fileBody.getInputStream();
        } catch (Exception e) {
            throw new DomainException("获取上传文件的流时失败。", e);
        }
        return uploadFileByForm(inputStream, fileBody.getContentType(), fileBody.getFilename());
    }

    /***
     * form表单提交
     * @param stream
     * @param contentType
     * @param filename
     * @return
     */
    public CommonResult<FileBytesResponse> uploadFileByForm(InputStream stream, ContentType contentType, String filename) {
        //构建请求对象
        HttpPost request = new HttpPost(ossClientProperty.getRootUrl() + UPLOAD_FILE_FORM_API);
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.setCharset(Charset.forName("utf-8"));
        builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
        //表单参数
        builder.addPart("appid", new StringBody(ossClientProperty.getAppid(), ContentType.MULTIPART_FORM_DATA));
        builder.addPart("appsecret", new StringBody(ossClientProperty.getAppsecret(), ContentType.MULTIPART_FORM_DATA));
        builder.addPart("project", new StringBody(ossClientProperty.getProject(), ContentType.MULTIPART_FORM_DATA));
        //添加文件
        builder.addBinaryBody("file", stream, contentType, filename);
        //参数赋值
        request.setEntity(builder.build());
        //执行上传文件请求
        return executeFileUpload(request);
    }

    /**
     * 分段下载文件内容
     *
     * @return
     */
    public FileContent downFile(String id, Integer from, Integer to) {
        CloseableHttpResponse closeableHttpResponse = null;

        try {
            //构建url地址
            URIBuilder builder = getUriBuilder(DOWN_FILE_API);
            builder.setParameter("id", id);
            //构建请求
            HttpGet get21312 = new HttpGet(builder.build());
            if (from != null && to != null) {
                //具有只获取部分数据的参数，转换为header的range获取
                get21312.addHeader("range", "bytes=" + from + "-" + to);
            }
            CloseableHttpClient httpClient = HttpClients.createDefault();
            closeableHttpResponse = httpClient.execute(get21312);
        } catch (Exception e) {
            throw new DomainException("下载文件失败", e);
        }
        int respondeCode = closeableHttpResponse.getStatusLine().getStatusCode();
        if (respondeCode == HttpStatus.SC_OK || respondeCode == HttpStatus.SC_PARTIAL_CONTENT) {
            try {
                InputStream stream = closeableHttpResponse.getEntity().getContent();
                //获取文件内容
                Header header = closeableHttpResponse.getFirstHeader("Content-Disposition");
                if (header == null) {
                    //未找到该header，则下载的应该不是文件
                    throw new DomainException("header中不存在Content-Disposition");
                }
                String fileName = header.toString();
                if (fileName == null || fileName.toLowerCase().indexOf("filename") < 0) {
                    //未找到该header，则下载的应该不是文件
                    throw new DomainException("header中不存在filename");
                }
                fileName = fileName.substring(fileName.toLowerCase().indexOf("filename") + 9);
                fileName = new String(fileName.getBytes("ISO8859-1"), "UTF-8");
                return new FileContent(fileName, stream);
            } catch (Exception x) {
                throw new DomainException("下载文件失败", x);
            }

        } else {
            throw new DomainException("下载文件失败");
        }
    }

    private URIBuilder getUriBuilder(String apiUrl) throws URISyntaxException {
        URIBuilder builder = new URIBuilder(ossClientProperty.getRootUrl() + apiUrl);
        List<NameValuePair> nvps2 = new ArrayList<NameValuePair>();
        nvps2.add(new BasicNameValuePair("appid", ossClientProperty.getAppid()));
        nvps2.add(new BasicNameValuePair("appsecret", ossClientProperty.getAppsecret()));
        nvps2.add(new BasicNameValuePair("project", ossClientProperty.getProject()));
        builder.setParameters(nvps2);
        return builder;
    }

    /***
     * 文件下载
     * @param id
     * @return
     */
    public FileContent downFile(String id) {
        return downFile(id, null, null);
    }

    /**
     * 转换数据库中文件为pdf
     *
     * @param id 数据库中文件id
     * @return 转换成功后的文件id，为空时表示不支持
     */
    public String convert2Pdf(String id) {
        try {
            return buildDerivationFile(id, CONVERT_TO_PDF_API);
        } catch (Exception e) {
            throw new DomainException("生成PDF时失败", e);
        }
    }

    private String buildDerivationFile(String fileId, String apiUrl) throws URISyntaxException, IOException {
        //构建url地址
        URIBuilder builder = getUriBuilder(apiUrl);
        builder.setParameter("id", fileId);
        //构建请求
        HttpGet get21312 = new HttpGet(builder.build());
        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse closeableHttpResponse = httpClient.execute(get21312);
        int respondeCode = closeableHttpResponse.getStatusLine().getStatusCode();
        if (respondeCode == HttpStatus.SC_OK) {
            //获取到结果
            String strResult = EntityUtils.toString(closeableHttpResponse.getEntity());
            CommonResult commonResult = CommonUtil.getJsonMapper().readValue(strResult, CommonResult.class);
            return commonResult.getData(true).toString();
        } else {
            throw new DomainException("构建衍生文件时服务器发送异常");
        }
    }

    /**
     * 生成数据库中文件的 缩略图
     *
     * @param id 数据库中文件id
     * @return 转换成功后的文件id，为空时表示不支持
     */
    public String buildThumbnail(String id) {
        try {
            return buildDerivationFile(id, BUILD_THUMBNAIL_API);
        } catch (Exception e) {
            throw new DomainException("生成缩略图时失败", e);
        }
    }

    /**
     * 获取衍生产品信息
     *
     * @param id   主文件id
     * @param type 衍生文件类别：缩略图、预览文件
     * @return
     */
    public DerivationFileInfo getDerivationFileInfo(String id, String type) {
        try {
            //构建url地址
            URIBuilder builder = getUriBuilder(GET_DERIVATION_FILE_API);
            builder.setParameter("id", id);
            builder.setParameter("type", type);
            //构建请求
            HttpGet get21312 = new HttpGet(builder.build());
            CloseableHttpClient httpClient = HttpClients.createDefault();
            CloseableHttpResponse closeableHttpResponse = httpClient.execute(get21312);
            //获取到结果
            String strResult = EntityUtils.toString(closeableHttpResponse.getEntity());
            CommonResult<DerivationFileInfo> commonResult = CommonUtil.getJsonMapper().readValue(strResult, new TypeReference<CommonResult<DerivationFileInfo>>() {
            });
            return commonResult.getData(true);
        } catch (Exception e) {
            throw new DomainException("获取衍生产品信息时失败", e);
        }
    }

    public static void main(String[] args) {
        OSSClientProperty ossClientProperty = new OSSClientProperty("http://localhost:8603/", "11111", "oss069729", "m9kek3km");
        OSSClient ossClient = new OSSClient(ossClientProperty);
        FileContent fileContent;
        String fileDic = "C:\\Users\\chen_\\Desktop\\oss测试文件";
        CommonResult<FileBytesResponse> responseCommonResult;
        long time1=System.currentTimeMillis();
        //1、上传测试
     /*    //1.1 上传doc文件
        File docFile = new File(fileDic + "\\doc.docx");
        responseCommonResult = ossClient.uploadFileByForm(docFile);
        System.out.println("上传doc文件成功。" + responseCommonResult.getData().getStore());
        String docFileId = responseCommonResult.getData().getId();*/
        //1.2 上传图片文件
        File imgFile = new File(fileDic + "\\图片.png");
        responseCommonResult = ossClient.uploadFileByForm(imgFile);
        System.out.println("上传图片成功。" + responseCommonResult.getData().getStore());
        String imgFileId = responseCommonResult.getData().getId();
        long time2=System.currentTimeMillis();
        System.out.println("耗时："+(time2-time1)+"ms");
        time1=System.currentTimeMillis();
        //1.2 上传视频文件
        File vedioFile = new File(fileDic + "\\视频.mp4");
        responseCommonResult = ossClient.uploadFileByForm(vedioFile);
        System.out.println("上传视频成功。" + responseCommonResult.getData().getStore());
        String vedioFileId = responseCommonResult.getData().getId();
        time2=System.currentTimeMillis();
        System.out.println("耗时："+(time2-time1)+"ms");
        time1=System.currentTimeMillis();

    }
}
