package cont.specialdata.rest.services.dto;

import lombok.Data;

/**
 * @author chenjiabin
 * @version 1.0
 * @date 2021/12/13 23:43
 */
@Data
public class ProvinceDetail {

    private String  provinceName;

    //单位家数
    private int danWeiCount;

    //参赛人数
    private int canSaiCount;

    //女人比例
    private double canSaiRatio;


}
